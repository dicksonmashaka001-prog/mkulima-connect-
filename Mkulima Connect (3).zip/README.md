# Mkulima Connect

Jukwaa la wakulima kusharikiana na kuuza mazao katika Afrika Mashariki.

## Huduma Zinazopatikana

- **Mazao**: Tangaza na uze mazao yako
- **Pembejeo**: Pata pembejeo za kilimo
- **Mbolea**: Nunua mbolea bora za kilimo
- **Mafunzo**: Jifunze mbinu za kisasa za kilimo
- **Bei**: Fuatilia bei za mazao Afrika Mashariki
- **Mazungumzo**: Jisikilize na wakulima wenzako

## Teknolojia

- **Frontend**: React 19, TypeScript, Tailwind CSS
- **Backend**: Cloudflare Workers, Hono framework
- **Database**: Cloudflare D1 (SQLite)
- **Deployment**: Cloudflare Workers

## Mfumo wa Malipo

- Siku 21 za majaribio bila malipo
- TSH 2,000 kwa miezi 18 ya matumizi
- Malipo kupitia: 0743649691

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Deploy to Cloudflare
wrangler deploy
```

## Msaada

Kwa msaada zaidi, wasiliana nasi kupitia app au email.

---

© 2024 Mkulima Connect. Haki zote zimehifadhiwa.
