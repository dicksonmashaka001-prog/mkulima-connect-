
ALTER TABLE payments ADD COLUMN plan_type TEXT DEFAULT 'monthly';
