
DROP TABLE IF EXISTS user_sessions;
DROP TABLE IF EXISTS offline_cache;
DELETE FROM users WHERE phone_number = '0743649691' AND name = 'DICKSON MALULU';
ALTER TABLE users DROP COLUMN phone_verified;
ALTER TABLE users DROP COLUMN trial_ended_at;
