
ALTER TABLE payments DROP COLUMN plan_type;
