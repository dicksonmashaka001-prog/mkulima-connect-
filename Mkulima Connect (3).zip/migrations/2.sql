
-- Add admin flag and phone auth fields
ALTER TABLE users ADD COLUMN phone_verified BOOLEAN DEFAULT 0;
ALTER TABLE users ADD COLUMN trial_ended_at DATETIME;

-- Create sessions table for phone auth
CREATE TABLE user_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  session_token TEXT NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create offline cache table for crops
CREATE TABLE offline_cache (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cache_key TEXT NOT NULL UNIQUE,
  cache_data TEXT NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Insert admin user (DICKSON MALULU)
INSERT OR IGNORE INTO users (
  phone_number, 
  name, 
  is_admin, 
  phone_verified,
  trial_started_at,
  created_at, 
  updated_at
) VALUES (
  '0743649691',
  'DICKSON MALULU',
  1,
  1,
  datetime('now'),
  datetime('now'),
  datetime('now')
);
