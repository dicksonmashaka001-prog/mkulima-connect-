
DROP TABLE payments;
DROP TABLE chat_messages;
DROP TABLE orders;
DROP TABLE posts;
DROP TABLE users;
