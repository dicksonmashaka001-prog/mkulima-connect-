# Mkulima Connect - Cloudflare Deployment Guide

## Hatua za Kuhost App Yako Cloudflare

### 1. Kupata Kodi Yako
Kodi yako iko kwenye folder hii. Unahitaji kuicopy kwenye kompyuta yako:

**Njia 1: Download kama ZIP**
- Browser: Bonyeza download button kwenye interface hii
- Download faili zote

**Njia 2: Copy files moja moja**
- Copy kila file kutoka hapa kwenye local folder

### 2. Unda Cloudflare Account
1. Enda https://dash.cloudflare.com
2. Jisajili account mpya (free account inatosha)
3. Verify email yako

### 3. Install Wrangler CLI
Kwenye terminal/command prompt:
```bash
npm install -g wrangler
```

### 4. Login kwa Cloudflare
```bash
wrangler login
```
- Itafungua browser
- Login kwa account yako ya Cloudflare

### 5. Setup Database
```bash
# Tengeneza database
wrangler d1 create mkulima-connect-db

# Note: Copy database ID itakayotokea
```

### 6. Edit wrangler.jsonc
Badilisha database ID kwenye wrangler.jsonc:
```json
{
  "name": "mkulima-connect",
  "main": "dist/index.js",
  "compatibility_date": "2024-12-01",
  "compatibility_flags": ["nodejs_compat"],
  "d1_databases": [
    {
      "binding": "DB",
      "database_name": "mkulima-connect-db",
      "database_id": "WEKA_DATABASE_ID_HAPA"
    }
  ]
}
```

### 7. Setup Database Schema
```bash
# Apply migrations
wrangler d1 execute mkulima-connect-db --file=migrations/001_initial_schema.sql
```

### 8. Deploy App
```bash
# Build app
npm run build

# Deploy
wrangler deploy
```

### 9. Custom Domain (Optional)
1. Cloudflare Dashboard → Workers & Pages
2. Chagua app yako
3. Custom domains → Add custom domain
4. Follow instructions

### 10. Environment Variables
Kwenye Cloudflare Dashboard:
1. Workers & Pages → mkulima-connect
2. Settings → Variables
3. Ongeza:
   - `MOCHA_USERS_SERVICE_API_KEY`
   - `MOCHA_USERS_SERVICE_API_URL`

## Database Schema File
Tengeneza folder `migrations/` na file `001_initial_schema.sql`:

```sql
-- Copy SQL schema kutoka database_schema
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT,
  phone_number TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  is_admin BOOLEAN DEFAULT 0,
  subscription_expires_at DATETIME,
  trial_started_at DATETIME,
  phone_verified BOOLEAN DEFAULT 0,
  trial_ended_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Add all other tables...
```

## Troubleshooting

### Error: "Database not found"
- Hakikisha database ID ni sahihi kwenye wrangler.jsonc
- Run `wrangler d1 list` kuona databases zako

### Error: "Authentication failed"
- Run `wrangler logout` kisha `wrangler login`

### Build errors
- Run `npm install` kwanza
- Hakikisha Node.js version ni 18 au zaidi

## Support
Kama una shida, check:
1. Cloudflare Workers documentation
2. Wrangler CLI docs
3. Console logs kwenye browser

App yako itakuwa available kwa URL kama:
https://mkulima-connect.your-subdomain.workers.dev
