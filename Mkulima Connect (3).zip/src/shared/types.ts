import z from "zod";

export const UserSchema = z.object({
  id: z.number(),
  email: z.string().optional(),
  phone_number: z.string(),
  name: z.string(),
  is_admin: z.boolean(),
  subscription_expires_at: z.string().nullable(),
  trial_started_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const PostSchema = z.object({
  id: z.number(),
  user_id: z.number(),
  category: z.enum(['mazao', 'pembejeo', 'mbolea', 'mafunzo']),
  title: z.string(),
  description: z.string().optional(),
  price: z.number().optional(),
  location: z.string().optional(),
  contact_info: z.string().optional(),
  image_url: z.string().optional(),
  video_url: z.string().optional(),
  is_active: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreatePostSchema = z.object({
  category: z.enum(['mazao', 'pembejeo', 'mbolea', 'mafunzo']),
  title: z.string().min(1),
  description: z.string().optional(),
  price: z.number().optional(),
  location: z.string().optional(),
  contact_info: z.string().optional(),
  image_url: z.string().optional(),
  video_url: z.string().optional(),
});

export const OrderSchema = z.object({
  id: z.number(),
  buyer_id: z.number(),
  seller_id: z.number(),
  post_id: z.number(),
  quantity: z.number().optional(),
  total_amount: z.number().optional(),
  commission_amount: z.number().optional(),
  status: z.enum(['pending', 'confirmed', 'completed', 'cancelled']),
  buyer_notes: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateOrderSchema = z.object({
  post_id: z.number(),
  quantity: z.number().optional(),
  total_amount: z.number().optional(),
  buyer_notes: z.string().optional(),
});

export const ChatMessageSchema = z.object({
  id: z.number(),
  sender_id: z.number(),
  receiver_id: z.number().optional(),
  message: z.string(),
  image_url: z.string().optional(),
  video_url: z.string().optional(),
  is_public: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateChatMessageSchema = z.object({
  receiver_id: z.number().optional(),
  message: z.string().min(1),
  image_url: z.string().optional(),
  video_url: z.string().optional(),
  is_public: z.boolean().default(false),
});

export const PriceDataSchema = z.object({
  crop: z.string(),
  country: z.string(),
  price: z.number(),
  unit: z.string(),
  date: z.string(),
});

export type User = z.infer<typeof UserSchema>;
export type Post = z.infer<typeof PostSchema>;
export type CreatePost = z.infer<typeof CreatePostSchema>;
export type Order = z.infer<typeof OrderSchema>;
export type CreateOrder = z.infer<typeof CreateOrderSchema>;
export type ChatMessage = z.infer<typeof ChatMessageSchema>;
export type CreateChatMessage = z.infer<typeof CreateChatMessageSchema>;
export type PriceData = z.infer<typeof PriceDataSchema>;
