import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { cors } from "hono/cors";
import { getCookie, setCookie } from "hono/cookie";
import { z } from 'zod';
import { 
  CreatePostSchema, 
  CreateOrderSchema,
  CreateChatMessageSchema
} from "@/shared/types";

// Extend Hono context to include user variables
declare module 'hono' {
  interface ContextVariableMap {
    user: any;
    userId: number;
  }
}

// Simple auth middleware for phone-based authentication
const authMiddleware = async (c: any, next: any) => {
  const sessionToken = getCookie(c, 'mkulima_session_token');
  
  if (!sessionToken) {
    return c.json({ error: 'Authentication required' }, 401);
  }

  try {
    const user = await c.env.DB.prepare(`
      SELECT u.* FROM users u
      JOIN user_sessions s ON u.id = s.user_id
      WHERE s.session_token = ? AND s.expires_at > datetime('now')
    `).bind(sessionToken).first();

    if (!user) {
      return c.json({ error: 'Invalid session' }, 401);
    }

    c.set('user', user);
    c.set('userId', user.id);
    await next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    return c.json({ error: 'Authentication failed' }, 401);
  }
};

const adminMiddleware = async (c: any, next: any) => {
  const user = c.get('user');
  
  if (!user || !user.is_admin) {
    return c.json({ error: 'Admin access required' }, 403);
  }
  
  await next();
};

const checkSubscription = (user: any) => {
  // Admin has unlimited access
  if (user.is_admin) {
    return { canPost: true, reason: 'admin' };
  }
  
  // Check if user has active subscription
  if (user.subscription_expires_at && new Date(user.subscription_expires_at) > new Date()) {
    return { canPost: true, reason: 'subscribed' };
  }
  
  // Check if user is in trial period (30 days)
  if (user.trial_started_at) {
    const trialStart = new Date(user.trial_started_at);
    const trialEnd = new Date(trialStart.getTime() + (30 * 24 * 60 * 60 * 1000));
    
    if (new Date() < trialEnd) {
      return { canPost: true, reason: 'trial' };
    }
  }
  
  return { canPost: false, reason: 'expired' };
};

const app = new Hono<{ Bindings: Env }>();

// CORS middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// AUTH ROUTES

// Check if phone number exists
app.post('/api/users/check-phone', zValidator('json', z.object({ phone_number: z.string() })), async (c) => {
  const { phone_number } = c.req.valid('json');
  
  try {
    const user = await c.env.DB.prepare('SELECT * FROM users WHERE phone_number = ?')
      .bind(phone_number).first();
    
    if (user) {
      // Create session for existing user
      const sessionToken = crypto.randomUUID();
      const expiresAt = new Date(Date.now() + (30 * 24 * 60 * 60 * 1000)); // 30 days
      
      await c.env.DB.prepare(`
        INSERT INTO user_sessions (user_id, session_token, expires_at, created_at, updated_at)
        VALUES (?, ?, ?, datetime('now'), datetime('now'))
      `).bind(user.id, sessionToken, expiresAt.toISOString()).run();
      
      setCookie(c, 'mkulima_session_token', sessionToken, {
        httpOnly: true,
        secure: true,
        sameSite: 'lax',
        maxAge: 30 * 24 * 60 * 60, // 30 days
      });
    }
    
    return c.json({ exists: !!user });
  } catch (error) {
    console.error('Error checking phone:', error);
    return c.json({ error: 'Failed to check phone number' }, 500);
  }
});

// Register new user
app.post('/api/users/register', zValidator('json', z.object({
  name: z.string(),
  phone_number: z.string()
})), async (c) => {
  const { name, phone_number } = c.req.valid('json');
  
  try {
    // Check if user already exists
    const existingUser = await c.env.DB.prepare('SELECT * FROM users WHERE phone_number = ?')
      .bind(phone_number).first();
    
    if (existingUser) {
      return c.json({ error: 'Namba ya simu tayari imetumika' }, 400);
    }
    
    // Create new user
    const userResult = await c.env.DB.prepare(`
      INSERT INTO users (name, phone_number, phone_verified, trial_started_at, created_at, updated_at)
      VALUES (?, ?, 1, datetime('now'), datetime('now'), datetime('now'))
    `).bind(name, phone_number).run();
    
    // Create session
    const sessionToken = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + (30 * 24 * 60 * 60 * 1000)); // 30 days
    
    await c.env.DB.prepare(`
      INSERT INTO user_sessions (user_id, session_token, expires_at, created_at, updated_at)
      VALUES (?, ?, ?, datetime('now'), datetime('now'))
    `).bind(userResult.meta.last_row_id, sessionToken, expiresAt.toISOString()).run();
    
    setCookie(c, 'mkulima_session_token', sessionToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60, // 30 days
    });
    
    return c.json({ success: true, user_id: userResult.meta.last_row_id });
  } catch (error) {
    console.error('Error registering user:', error);
    return c.json({ error: 'Failed to register user' }, 500);
  }
});

// Get current user
app.get('/api/users/me', authMiddleware, async (c) => {
  const user = c.get('user');
  const subscription = checkSubscription(user);
  
  return c.json({
    ...user,
    subscription_status: subscription
  });
});

// Logout
app.post('/api/logout', authMiddleware, async (c) => {
  const sessionToken = getCookie(c, 'mkulima_session_token');
  
  if (sessionToken) {
    await c.env.DB.prepare('DELETE FROM user_sessions WHERE session_token = ?')
      .bind(sessionToken).run();
  }
  
  setCookie(c, 'mkulima_session_token', '', {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    maxAge: 0,
  });
  
  return c.json({ success: true });
});

// PAYMENT ROUTES

// Submit payment
app.post('/api/payments', authMiddleware, zValidator('json', z.object({
  amount: z.number(),
  phone_number: z.string(),
  plan_type: z.enum(['monthly', 'yearly']).optional()
})), async (c) => {
  const { amount, phone_number, plan_type } = c.req.valid('json');
  const user = c.get('user');
  
  try {
    const result = await c.env.DB.prepare(`
      INSERT INTO payments (user_id, amount, phone_number, plan_type, created_at, updated_at)
      VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(user.id, amount, phone_number, plan_type || 'monthly').run();
    
    return c.json({ 
      success: true, 
      payment_id: result.meta.last_row_id,
      message: 'Malipo yamekuwa yametumwa. Itadhibitishwa haraka.'
    });
  } catch (error) {
    console.error('Error creating payment:', error);
    return c.json({ error: 'Failed to submit payment' }, 500);
  }
});

// ADMIN ROUTES

// Get admin stats
app.get('/api/admin/stats', authMiddleware, adminMiddleware, async (c) => {
  try {
    const totalUsers = await c.env.DB.prepare('SELECT COUNT(*) as count FROM users').first();
    const activePosts = await c.env.DB.prepare('SELECT COUNT(*) as count FROM posts WHERE is_active = 1').first();
    const totalRevenue = await c.env.DB.prepare('SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE status = "confirmed"').first();
    const pendingPayments = await c.env.DB.prepare('SELECT COUNT(*) as count FROM payments WHERE status = "pending"').first();
    
    return c.json({
      totalUsers: totalUsers?.count || 0,
      activePosts: activePosts?.count || 0,
      totalRevenue: totalRevenue?.total || 0,
      pendingPayments: pendingPayments?.count || 0,
    });
  } catch (error) {
    console.error('Error fetching admin stats:', error);
    return c.json({ error: 'Failed to fetch stats' }, 500);
  }
});

// Get all users
app.get('/api/admin/users', authMiddleware, adminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(`
      SELECT * FROM users ORDER BY created_at DESC
    `).all();
    
    return c.json(results);
  } catch (error) {
    console.error('Error fetching users:', error);
    return c.json({ error: 'Failed to fetch users' }, 500);
  }
});

// Get all payments
app.get('/api/admin/payments', authMiddleware, adminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(`
      SELECT p.*, u.name as user_name
      FROM payments p
      JOIN users u ON p.user_id = u.id
      ORDER BY p.created_at DESC
    `).all();
    
    return c.json(results);
  } catch (error) {
    console.error('Error fetching payments:', error);
    return c.json({ error: 'Failed to fetch payments' }, 500);
  }
});

// Confirm payment
app.post('/api/admin/payments/:id/confirm', authMiddleware, adminMiddleware, async (c) => {
  const paymentId = c.req.param('id');
  
  try {
    // Update payment status
    await c.env.DB.prepare(`
      UPDATE payments SET status = 'confirmed', updated_at = datetime('now')
      WHERE id = ?
    `).bind(paymentId).run();
    
    // Get payment info to update user subscription
    const payment = await c.env.DB.prepare(`
      SELECT * FROM payments WHERE id = ?
    `).bind(paymentId).first();
    
    if (payment) {
      // Extend subscription based on payment plan
      const subscriptionEnd = new Date();
      const planType = payment.plan_type || 'monthly';
      
      if (planType === 'yearly') {
        subscriptionEnd.setFullYear(subscriptionEnd.getFullYear() + 1);
      } else {
        subscriptionEnd.setMonth(subscriptionEnd.getMonth() + 1);
      }
      
      await c.env.DB.prepare(`
        UPDATE users SET 
          subscription_expires_at = ?,
          updated_at = datetime('now')
        WHERE id = ?
      `).bind(subscriptionEnd.toISOString(), payment.user_id).run();
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error confirming payment:', error);
    return c.json({ error: 'Failed to confirm payment' }, 500);
  }
});

// GET /api/posts - Get posts by category (with offline cache for mazao)
app.get('/api/posts', async (c) => {
  const category = c.req.query('category');
  
  try {
    let sql = 'SELECT p.*, u.name as user_name FROM posts p JOIN users u ON p.user_id = u.id WHERE p.is_active = 1';
    const params: any[] = [];
    
    if (category) {
      sql += ' AND p.category = ?';
      params.push(category);
    }
    
    sql += ' ORDER BY p.created_at DESC';
    
    const { results } = await c.env.DB.prepare(sql).bind(...params).all();
    
    // Cache mazao posts for offline access
    if (category === 'mazao') {
      const cacheKey = 'posts_mazao';
      const expiresAt = new Date(Date.now() + (24 * 60 * 60 * 1000)); // 24 hours
      
      await c.env.DB.prepare(`
        INSERT OR REPLACE INTO offline_cache (cache_key, cache_data, expires_at, updated_at)
        VALUES (?, ?, ?, datetime('now'))
      `).bind(cacheKey, JSON.stringify(results), expiresAt.toISOString()).run();
    }
    
    return c.json(results);
  } catch (error) {
    console.error('Error fetching posts:', error);
    return c.json({ error: 'Failed to fetch posts' }, 500);
  }
});

// POST /api/posts - Create a new post
app.post('/api/posts', authMiddleware, zValidator('json', CreatePostSchema), async (c) => {
  const data = c.req.valid('json');
  const user = c.get('user');
  
  try {
    // Check subscription status
    const subscription = checkSubscription(user);
    
    if (!subscription.canPost) {
      return c.json({ 
        error: 'Muda wako wa majaribio umeisha. Lipa TSH 2,000 kwa mwezi au TSH 24,000 kwa mwaka kuendelea kutumia huduma.',
        requiresPayment: true 
      }, 402);
    }
    
    const result = await c.env.DB.prepare(`
      INSERT INTO posts (user_id, category, title, description, price, location, contact_info, image_url, video_url, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      user.id,
      data.category,
      data.title,
      data.description || null,
      data.price || null,
      data.location || null,
      data.contact_info || null,
      data.image_url || null,
      data.video_url || null
    ).run();
    
    return c.json({ id: result.meta.last_row_id, ...data }, 201);
  } catch (error) {
    console.error('Error creating post:', error);
    return c.json({ error: 'Failed to create post' }, 500);
  }
});

// GET /api/orders - Get orders for a user
app.get('/api/orders', authMiddleware, async (c) => {
  const userId = c.get('userId');
  
  try {
    const { results } = await c.env.DB.prepare(`
      SELECT o.*, p.title as post_title, p.price as post_price, u.name as seller_name
      FROM orders o
      JOIN posts p ON o.post_id = p.id
      JOIN users u ON o.seller_id = u.id
      WHERE o.buyer_id = ? OR o.seller_id = ?
      ORDER BY o.created_at DESC
    `).bind(userId, userId).all();
    
    return c.json(results);
  } catch (error) {
    console.error('Error fetching orders:', error);
    return c.json({ error: 'Failed to fetch orders' }, 500);
  }
});

// POST /api/orders - Create a new order
app.post('/api/orders', authMiddleware, zValidator('json', CreateOrderSchema), async (c) => {
  const data = c.req.valid('json');
  const userId = c.get('userId');
  
  try {
    // Get the post to find seller_id
    const post = await c.env.DB.prepare('SELECT * FROM posts WHERE id = ?')
      .bind(data.post_id).first();
    
    if (!post) {
      return c.json({ error: 'Post not found' }, 404);
    }
    
    const commission_rate = 0.01; // 1%
    const commission_amount = data.total_amount ? data.total_amount * commission_rate : 0;
    
    const result = await c.env.DB.prepare(`
      INSERT INTO orders (buyer_id, seller_id, post_id, quantity, total_amount, commission_amount, buyer_notes, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      userId,
      post.user_id,
      data.post_id,
      data.quantity || null,
      data.total_amount || null,
      commission_amount,
      data.buyer_notes || null
    ).run();
    
    return c.json({ id: result.meta.last_row_id, ...data }, 201);
  } catch (error) {
    console.error('Error creating order:', error);
    return c.json({ error: 'Failed to create order' }, 500);
  }
});

// GET /api/chat/messages - Get chat messages
app.get('/api/chat/messages', authMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(`
      SELECT cm.*, u.name as sender_name
      FROM chat_messages cm
      JOIN users u ON cm.sender_id = u.id
      WHERE cm.is_public = 1 
      ORDER BY cm.created_at ASC
    `).all();
    
    return c.json(results);
  } catch (error) {
    console.error('Error fetching chat messages:', error);
    return c.json({ error: 'Failed to fetch messages' }, 500);
  }
});

// POST /api/chat/messages - Send a chat message
app.post('/api/chat/messages', authMiddleware, zValidator('json', CreateChatMessageSchema), async (c) => {
  const data = c.req.valid('json');
  const userId = c.get('userId');
  
  try {
    const result = await c.env.DB.prepare(`
      INSERT INTO chat_messages (sender_id, receiver_id, message, image_url, video_url, is_public, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      userId,
      data.receiver_id || null,
      data.message,
      data.image_url || null,
      data.video_url || null,
      data.is_public ? 1 : 0
    ).run();
    
    return c.json({ id: result.meta.last_row_id, ...data }, 201);
  } catch (error) {
    console.error('Error creating message:', error);
    return c.json({ error: 'Failed to send message' }, 500);
  }
});

// Health check
app.get('/api/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

export default app;
