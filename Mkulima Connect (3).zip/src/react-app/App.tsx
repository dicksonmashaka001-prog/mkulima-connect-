import { BrowserRouter as Router, Routes, Route } from "react-router";
import HomePage from "@/react-app/pages/Home";
import Pembejeo from "@/react-app/pages/Pembejeo";
import Mbolea from "@/react-app/pages/Mbolea";
import Mafunzo from "@/react-app/pages/Mafunzo";
import Bei from "@/react-app/pages/Bei";
import Chat from "@/react-app/pages/Chat";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/pembejeo" element={<Pembejeo />} />
        <Route path="/mbolea" element={<Mbolea />} />
        <Route path="/mafunzo" element={<Mafunzo />} />
        <Route path="/bei" element={<Bei />} />
        <Route path="/chat" element={<Chat />} />
      </Routes>
    </Router>
  );
}
