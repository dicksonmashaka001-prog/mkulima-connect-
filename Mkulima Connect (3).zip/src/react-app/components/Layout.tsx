import { ReactNode, useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router';
import { Sprout, ShoppingCart, Zap, GraduationCap, TrendingUp, MessageSquare, User, LogOut, Settings } from 'lucide-react';
import AuthModal from './AuthModal';
import AdminSettings from './AdminSettings';

interface LayoutProps {
  children: ReactNode;
}

interface User {
  id: number;
  name: string;
  phone_number: string;
  is_admin: boolean;
  subscription_status: {
    canPost: boolean;
    reason: string;
  };
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const [user, setUser] = useState<User | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showAdminSettings, setShowAdminSettings] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUser();
  }, []);

  const fetchUser = async () => {
    try {
      const response = await fetch('/api/users/me');
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      }
    } catch (error) {
      console.error('Error fetching user:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAuth = async () => {
    setShowAuthModal(false);
    await fetchUser();
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/logout', { method: 'POST' });
      setUser(null);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const navigation = [
    { name: 'Mazao', href: '/', icon: Sprout },
    { name: 'Pembejeo', href: '/pembejeo', icon: ShoppingCart },
    { name: 'Mbolea', href: '/mbolea', icon: Zap },
    { name: 'Mafunzo', href: '/mafunzo', icon: GraduationCap },
    { name: 'Bei za Mazao', href: '/bei', icon: TrendingUp },
    { name: 'Mazungumzo', href: '/chat', icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-2 border-green-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-green-700 rounded-lg flex items-center justify-center">
                <Sprout className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-green-800">Mkulima Connect</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {loading ? (
                <div className="w-5 h-5 animate-spin rounded-full border-2 border-green-600 border-t-transparent"></div>
              ) : user ? (
                <>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-green-700 font-medium">{user.name}</span>
                    {!user.subscription_status.canPost && (
                      <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full">
                        Malipo yamehitajika
                      </span>
                    )}
                    {user.subscription_status.reason === 'trial' && (
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                        Majaribio (30 siku)
                      </span>
                    )}
                  </div>
                  
                  {user.is_admin && (
                    <button
                      onClick={() => setShowAdminSettings(true)}
                      className="p-2 text-green-700 hover:bg-green-100 rounded-lg transition-colors"
                      title="Mipangilio ya Admin"
                    >
                      <Settings className="w-5 h-5" />
                    </button>
                  )}
                  
                  <button
                    onClick={handleLogout}
                    className="p-2 text-green-700 hover:bg-green-100 rounded-lg transition-colors"
                    title="Toka"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-2 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-200 font-medium flex items-center space-x-2"
                >
                  <User className="w-4 h-4" />
                  <span>Ingia</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-gradient-to-r from-green-600 to-green-700 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.href;
              
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`flex items-center space-x-2 px-3 py-4 text-sm font-medium whitespace-nowrap transition-all ${
                    isActive
                      ? 'text-white bg-green-800 border-b-2 border-green-300'
                      : 'text-green-100 hover:text-white hover:bg-green-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      {/* Modals */}
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onAuth={handleAuth}
        />
      )}

      {showAdminSettings && user?.is_admin && (
        <AdminSettings onClose={() => setShowAdminSettings(false)} />
      )}
    </div>
  );
}
