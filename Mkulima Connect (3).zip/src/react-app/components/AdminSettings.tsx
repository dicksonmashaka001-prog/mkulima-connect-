import { useState, useEffect } from 'react';
import { Settings, Users, CreditCard, BarChart3, Shield, X } from 'lucide-react';

interface AdminSettingsProps {
  onClose: () => void;
}

interface AdminStats {
  totalUsers: number;
  activePosts: number;
  totalRevenue: number;
  pendingPayments: number;
}

export default function AdminSettings({ onClose }: AdminSettingsProps) {
  const [activeTab, setActiveTab] = useState<'stats' | 'users' | 'payments' | 'settings'>('stats');
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0,
    activePosts: 0,
    totalRevenue: 0,
    pendingPayments: 0,
  });
  const [users, setUsers] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchStats();
    if (activeTab === 'users') fetchUsers();
    if (activeTab === 'payments') fetchPayments();
  }, [activeTab]);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/admin/stats');
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/users');
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      }
    } catch (error) {
      console.error('Error fetching users:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPayments = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/payments');
      if (response.ok) {
        const data = await response.json();
        setPayments(data);
      }
    } catch (error) {
      console.error('Error fetching payments:', error);
    } finally {
      setLoading(false);
    }
  };

  const confirmPayment = async (paymentId: number) => {
    try {
      const response = await fetch(`/api/admin/payments/${paymentId}/confirm`, {
        method: 'POST',
      });
      if (response.ok) {
        fetchPayments();
        fetchStats();
      }
    } catch (error) {
      console.error('Error confirming payment:', error);
    }
  };

  const tabs = [
    { id: 'stats', name: 'Takwimu', icon: BarChart3 },
    { id: 'users', name: 'Watumiaji', icon: Users },
    { id: 'payments', name: 'Malipo', icon: CreditCard },
    { id: 'settings', name: 'Mipangilio', icon: Settings },
  ];

  const formatNumber = (num: number) => num.toLocaleString();
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('sw-TZ', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-green-200 bg-gradient-to-r from-green-600 to-green-700">
          <div className="flex items-center space-x-3">
            <Shield className="w-6 h-6 text-white" />
            <h2 className="text-xl font-bold text-white">Mipangilio ya Admin</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-green-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="flex h-[calc(90vh-80px)]">
          {/* Sidebar */}
          <div className="w-64 bg-green-50 border-r border-green-200">
            <div className="p-4">
              <div className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                        activeTab === tab.id
                          ? 'bg-green-600 text-white'
                          : 'text-green-700 hover:bg-green-100'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{tab.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {activeTab === 'stats' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900">Takwimu za Jumla</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-100">Watumiaji Wote</p>
                        <p className="text-2xl font-bold">{formatNumber(stats.totalUsers)}</p>
                      </div>
                      <Users className="w-8 h-8 text-blue-200" />
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-green-100">Mazao Yaliyotangazwa</p>
                        <p className="text-2xl font-bold">{formatNumber(stats.activePosts)}</p>
                      </div>
                      <BarChart3 className="w-8 h-8 text-green-200" />
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-purple-100">Mapato (TSH)</p>
                        <p className="text-2xl font-bold">{formatNumber(stats.totalRevenue)}</p>
                      </div>
                      <CreditCard className="w-8 h-8 text-purple-200" />
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-orange-100">Malipo Yasubiriyo</p>
                        <p className="text-2xl font-bold">{formatNumber(stats.pendingPayments)}</p>
                      </div>
                      <CreditCard className="w-8 h-8 text-orange-200" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900">Watumiaji Wote</h3>
                
                {loading ? (
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
                  </div>
                ) : (
                  <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Jina</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Simu</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Hali ya Malipo</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Alipojisajili</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {users.map((user) => (
                          <tr key={user.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 text-sm font-medium text-gray-900">{user.name}</td>
                            <td className="px-6 py-4 text-sm text-gray-700">{user.phone_number}</td>
                            <td className="px-6 py-4 text-sm">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                user.subscription_expires_at && new Date(user.subscription_expires_at) > new Date()
                                  ? 'bg-green-100 text-green-800'
                                  : user.trial_started_at && new Date(user.trial_started_at).getTime() + (21 * 24 * 60 * 60 * 1000) > new Date().getTime()
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {user.subscription_expires_at && new Date(user.subscription_expires_at) > new Date()
                                  ? 'Amelipa'
                                  : user.trial_started_at && new Date(user.trial_started_at).getTime() + (21 * 24 * 60 * 60 * 1000) > new Date().getTime()
                                  ? 'Majaribio'
                                  : 'Hajamaliza'
                                }
                              </span>
                            </td>
                            <td className="px-6 py-4 text-sm text-gray-500">{formatDate(user.created_at)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'payments' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900">Malipo</h3>
                
                {loading ? (
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
                  </div>
                ) : (
                  <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Mtumiaji</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Kiasi</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Simu</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Hali</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Tarehe</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Vitendo</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {payments.map((payment) => (
                          <tr key={payment.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 text-sm font-medium text-gray-900">{payment.user_name}</td>
                            <td className="px-6 py-4 text-sm text-gray-700">TSH {formatNumber(payment.amount)}</td>
                            <td className="px-6 py-4 text-sm text-gray-700">{payment.phone_number}</td>
                            <td className="px-6 py-4 text-sm">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                payment.status === 'confirmed'
                                  ? 'bg-green-100 text-green-800'
                                  : payment.status === 'pending'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {payment.status === 'confirmed' ? 'Imedhibitishwa' : 
                                 payment.status === 'pending' ? 'Inasubiri' : 'Imeghairi'}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-sm text-gray-500">{formatDate(payment.created_at)}</td>
                            <td className="px-6 py-4 text-sm">
                              {payment.status === 'pending' && (
                                <button
                                  onClick={() => confirmPayment(payment.id)}
                                  className="bg-green-600 text-white px-3 py-1 rounded-lg text-xs hover:bg-green-700 transition-colors"
                                >
                                  Dhibitisha
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900">Mipangilio ya App</h3>
                
                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">Ada ya Commission</h4>
                        <p className="text-sm text-gray-600">Asilimia ya kila muamala</p>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-green-600">1%</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">Bei ya Subscription</h4>
                        <p className="text-sm text-gray-600">Mwezi: TSH 2,000 | Mwaka: TSH 24,000</p>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-green-600">Flexible</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">Free Trial</h4>
                        <p className="text-sm text-gray-600">Muda wa majaribio ya bure</p>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-green-600">30 Siku</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">Namba ya Malipo</h4>
                        <p className="text-sm text-gray-600">Mobile Money</p>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-green-600">0743649691</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
