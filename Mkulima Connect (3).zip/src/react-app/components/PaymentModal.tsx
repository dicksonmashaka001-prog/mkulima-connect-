import { useState } from 'react';
import { X, CreditCard, Phone } from 'lucide-react';

interface PaymentModalProps {
  onClose: () => void;
  onPayment: () => void;
}

export default function PaymentModal({ onClose, onPayment }: PaymentModalProps) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('monthly');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: selectedPlan === 'monthly' ? 2000 : 24000,
          phone_number: phoneNumber,
          plan_type: selectedPlan,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        alert(data.message);
        onPayment();
        onClose();
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Hitilafu imetokea');
      }
    } catch (err) {
      setError('Hitilafu imetokea. Jaribu tena.');
      console.error('Payment error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-green-200">
          <h2 className="text-xl font-bold text-green-800">Malipo ya Subscription</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-green-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-green-700" />
          </button>
        </div>

        {/* Form */}
        <div className="p-6">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-green-700 rounded-full flex items-center justify-center mx-auto mb-4">
              <CreditCard className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Chagua Mpangilio wa Malipo
            </h3>
            <p className="text-gray-600 mb-2">
              Lipa kupitia Mobile Money ili kuendelea kutumia huduma za app
            </p>
            <p className="text-sm text-orange-600 font-medium">
              Muda wako wa majaribio umeisha. Utaweza kuona mazao na mazungumzo lakini hutaweza kutuma.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Plan Selection */}
            <div className="space-y-3">
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Chagua Mpangilio wa Malipo
              </label>
              
              <div className="grid grid-cols-1 gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedPlan('monthly')}
                  className={`p-4 border-2 rounded-lg text-left transition-colors ${
                    selectedPlan === 'monthly'
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-semibold text-gray-900">Mwezi Mmoja</h4>
                      <p className="text-sm text-gray-600">Malipo ya kila mwezi</p>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold text-green-600">TSH 2,000</span>
                      <p className="text-xs text-gray-500">/mwezi</p>
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedPlan('yearly')}
                  className={`p-4 border-2 rounded-lg text-left transition-colors relative ${
                    selectedPlan === 'yearly'
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                >
                  <div className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs px-2 py-1 rounded-full">
                    Okoa TSH 500
                  </div>
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-semibold text-gray-900">Mwaka Mzima</h4>
                      <p className="text-sm text-gray-600">Malipo ya mara moja</p>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold text-green-600">TSH 24,000</span>
                      <p className="text-xs text-gray-500">/mwaka</p>
                      <p className="text-xs text-orange-600">Badala ya TSH 24,000</p>
                    </div>
                  </div>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Phone className="w-4 h-4 inline mr-1" />
                Namba ya Simu ya Malipo
              </label>
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                required
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="0743649691"
              />
            </div>

            <div className="bg-gradient-to-r from-green-50 to-green-100 border border-green-300 rounded-lg p-4 mb-4">
              <h4 className="font-semibold text-green-800 mb-3 text-center">Namba ya Malipo ya Admin</h4>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-700 bg-white rounded-lg py-3 px-4 border-2 border-green-500">
                  0743649691
                </div>
                <p className="text-sm text-green-600 mt-2">
                  Tuma TSH {selectedPlan === 'monthly' ? '2,000' : '24,000'} kwenye namba hii
                </p>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-800 mb-2">Maagizo ya Malipo:</h4>
              <ol className="text-sm text-blue-700 space-y-2">
                <li><strong>1.</strong> Tuma TSH {selectedPlan === 'monthly' ? '2,000' : '24,000'} kwenda <strong>0743649691</strong></li>
                <li><strong>2.</strong> Andika ujumbe: <strong>"MKULIMA CONNECT {selectedPlan === 'monthly' ? 'MWEZI' : 'MWAKA'}"</strong></li>
                <li><strong>3.</strong> Jaza namba yako ya simu hapo chini</li>
                <li><strong>4.</strong> Bonyeza "Tuma Malipo" ili kutuma ombi</li>
                <li><strong>5.</strong> Subiri admin kukudhibitishia malipo (chini ya dakika 30)</li>
              </ol>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}

            <div className="flex space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Ghairi
              </button>
              <button
                type="submit"
                disabled={loading || !phoneNumber}
                className="flex-1 bg-gradient-to-r from-green-600 to-green-700 text-white py-2 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
              >
                {loading ? 'Inatuma...' : 'Tuma Malipo'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
