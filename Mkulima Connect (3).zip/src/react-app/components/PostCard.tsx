import { MapPin, Phone, Clock } from 'lucide-react';
import { Post } from '@/shared/types';

interface PostCardProps {
  post: Post;
  onOrder?: (post: Post) => void;
}

export default function PostCard({ post, onOrder }: PostCardProps) {
  const formatPrice = (price?: number) => {
    if (!price) return 'Bei haijaorodheshwa';
    return `TSH ${price.toLocaleString()}`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('sw-TZ', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-green-200 overflow-hidden hover:shadow-lg transition-all duration-300 hover:border-green-400">
      {post.image_url && (
        <div className="h-48 bg-gray-200 overflow-hidden">
          <img
            src={post.image_url}
            alt={post.title}
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          />
        </div>
      )}
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">
            {post.title}
          </h3>
          <span className="text-xl font-bold text-green-600">
            {formatPrice(post.price)}
          </span>
        </div>
        
        {post.description && (
          <p className="text-gray-600 text-sm mb-4 line-clamp-3">
            {post.description}
          </p>
        )}
        
        <div className="space-y-2 mb-4">
          {post.location && (
            <div className="flex items-center text-sm text-gray-500">
              <MapPin className="w-4 h-4 mr-2 text-green-600" />
              <span>{post.location}</span>
            </div>
          )}
          
          {post.contact_info && (
            <div className="flex items-center text-sm text-gray-500">
              <Phone className="w-4 h-4 mr-2 text-green-600" />
              <span>{post.contact_info}</span>
            </div>
          )}
          
          <div className="flex items-center text-sm text-gray-500">
            <Clock className="w-4 h-4 mr-2 text-green-600" />
            <span>{formatDate(post.created_at)}</span>
          </div>
        </div>
        
        {onOrder && (
          <button
            onClick={() => onOrder(post)}
            className="w-full bg-gradient-to-r from-green-600 to-green-700 text-white py-2 px-4 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-200 font-medium"
          >
            Weka Oda
          </button>
        )}
      </div>
    </div>
  );
}
