import { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import Layout from '@/react-app/components/Layout';
import PostCard from '@/react-app/components/PostCard';
import PostForm from '@/react-app/components/PostForm';
import { Post } from '@/shared/types';

export default function Pembejeo() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPostForm, setShowPostForm] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    fetchPosts();
    fetchUser();
  }, []);

  const fetchUser = async () => {
    try {
      const response = await fetch('/api/users/me');
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      }
    } catch (error) {
      // User not logged in
    }
  };

  const fetchPosts = async () => {
    try {
      const response = await fetch('/api/posts?category=pembejeo');
      if (response.ok) {
        const data = await response.json();
        setPosts(data);
      }
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePost = async (postData: any) => {
    try {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(postData),
      });

      if (response.ok) {
        fetchPosts(); // Refresh posts
        setShowPostForm(false);
      } else {
        const error = await response.json();
        if (error.requiresPayment) {
          alert(error.error);
        } else {
          console.error('Error creating post:', error);
        }
      }
    } catch (error) {
      console.error('Error creating post:', error);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-md border border-green-200 p-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold text-green-800 mb-2">Pembejeo za Kilimo</h2>
              <p className="text-gray-600">Pata pembejeo bora za kilimo kwa bei nafuu</p>
            </div>
            {user ? (
              user.subscription_status?.canPost ? (
                <button 
                  onClick={() => setShowPostForm(true)}
                  className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-200 flex items-center space-x-2 font-medium"
                >
                  <Plus className="w-5 h-5" />
                  <span>Ongeza Pembejeo</span>
                </button>
              ) : (
                <div className="text-center">
                  <p className="text-orange-600 font-medium mb-2">Malipo yamehitajika ili kupost pembejeo</p>
                  <p className="text-sm text-gray-600">Tuma TSH 2,000 kwenda 0743649691</p>
                </div>
              )
            ) : (
              <button 
                onClick={() => setShowPostForm(true)}
                disabled={true}
                className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-200 flex items-center space-x-2 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Plus className="w-5 h-5" />
                <span>Ongeza Pembejeo</span>
              </button>
            )}
          </div>
        </div>

        {/* Posts Grid */}
        {posts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                onOrder={(post) => console.log('Order placed for:', post)}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-md border border-green-200 p-12 text-center">
            <div className="text-gray-400 mb-4">
              <Plus className="w-16 h-16 mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Hakuna pembejeo zilizotangazwa</h3>
            <p className="text-gray-500 mb-6">Kuwa wa kwanza kutangaza pembejeo zako hapa</p>
            <button 
              onClick={() => setShowPostForm(true)}
              disabled={!user}
              className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-200 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Tangaza Pembejeo Zako
            </button>
          </div>
        )}

        {/* Post Form Modal */}
        {showPostForm && (
          <PostForm
            category="pembejeo"
            onClose={() => setShowPostForm(false)}
            onSubmit={handleCreatePost}
          />
        )}
      </div>
    </Layout>
  );
}
