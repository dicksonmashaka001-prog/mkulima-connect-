import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import Layout from '@/react-app/components/Layout';
import { PriceData } from '@/shared/types';

export default function Bei() {
  const [priceData, setPriceData] = useState<PriceData[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCountry, setSelectedCountry] = useState<string>('all');

  const countries = ['Tanzania', 'Kenya', 'Uganda', 'Rwanda', 'Burundi'];

  useEffect(() => {
    fetchPriceData();
  }, [selectedCountry]);

  const fetchPriceData = async () => {
    try {
      // Mock data for now - in real app this would come from API
      const mockData: PriceData[] = [
        { crop: 'Mahindi', country: 'Tanzania', price: 800, unit: 'kilo', date: '2024-12-01' },
        { crop: 'Maharage', country: 'Tanzania', price: 2500, unit: 'kilo', date: '2024-12-01' },
        { crop: 'Mchele', country: 'Tanzania', price: 2000, unit: 'kilo', date: '2024-12-01' },
        { crop: 'Mahindi', country: 'Kenya', price: 850, unit: 'kilo', date: '2024-12-01' },
        { crop: 'Maharage', country: 'Kenya', price: 2800, unit: 'kilo', date: '2024-12-01' },
        { crop: 'Mchele', country: 'Kenya', price: 2200, unit: 'kilo', date: '2024-12-01' },
        { crop: 'Mahindi', country: 'Uganda', price: 750, unit: 'kilo', date: '2024-12-01' },
        { crop: 'Maharage', country: 'Uganda', price: 2300, unit: 'kilo', date: '2024-12-01' },
        { crop: 'Mchele', country: 'Uganda', price: 1900, unit: 'kilo', date: '2024-12-01' },
      ];
      
      const filteredData = selectedCountry === 'all' 
        ? mockData 
        : mockData.filter(item => item.country === selectedCountry);
      
      setPriceData(filteredData);
    } catch (error) {
      console.error('Error fetching price data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price: number) => {
    return `TSH ${price.toLocaleString()}`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('sw-TZ', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getPriceIcon = (crop: string, country: string) => {
    // Mock logic for price trends
    const hash = (crop + country).length % 3;
    if (hash === 0) return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (hash === 1) return <TrendingDown className="w-4 h-4 text-red-600" />;
    return <Minus className="w-4 h-4 text-gray-600" />;
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-md border border-green-200 p-6">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h2 className="text-2xl font-bold text-green-800 mb-2">Bei za Mazao Afrika Mashariki</h2>
              <p className="text-gray-600">Fuatilia bei za mazao katika nchi za Afrika Mashariki</p>
            </div>
          </div>
          
          {/* Country Filter */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedCountry('all')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedCountry === 'all'
                  ? 'bg-green-600 text-white'
                  : 'bg-green-100 text-green-700 hover:bg-green-200'
              }`}
            >
              Nchi Zote
            </button>
            {countries.map((country) => (
              <button
                key={country}
                onClick={() => setSelectedCountry(country)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  selectedCountry === country
                    ? 'bg-green-600 text-white'
                    : 'bg-green-100 text-green-700 hover:bg-green-200'
                }`}
              >
                {country}
              </button>
            ))}
          </div>
        </div>

        {/* Price Table */}
        <div className="bg-white rounded-xl shadow-md border border-green-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-green-50 border-b border-green-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-green-800">Zao</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-green-800">Nchi</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-green-800">Bei</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-green-800">Kipimo</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-green-800">Mwelekeo</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-green-800">Tarehe</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {priceData.map((item, index) => (
                  <tr key={index} className="hover:bg-green-50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{item.crop}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{item.country}</td>
                    <td className="px-6 py-4 text-sm font-semibold text-right text-green-700">
                      {formatPrice(item.price)}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">{item.unit}</td>
                    <td className="px-6 py-4 text-center">
                      {getPriceIcon(item.crop, item.country)}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">{formatDate(item.date)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Legend */}
        <div className="bg-white rounded-xl shadow-md border border-green-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Ufafanuzi wa Alama</h3>
          <div className="flex flex-wrap gap-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-sm text-gray-700">Bei inapanda</span>
            </div>
            <div className="flex items-center space-x-2">
              <TrendingDown className="w-4 h-4 text-red-600" />
              <span className="text-sm text-gray-700">Bei inashuka</span>
            </div>
            <div className="flex items-center space-x-2">
              <Minus className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-700">Bei imara</span>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
