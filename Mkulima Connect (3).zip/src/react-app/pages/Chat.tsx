import { useState, useEffect } from 'react';
import { Send, Image, Video, Phone } from 'lucide-react';
import Layout from '@/react-app/components/Layout';
import { ChatMessage } from '@/shared/types';

export default function Chat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    fetchMessages();
    fetchUser();
  }, []);

  const fetchUser = async () => {
    try {
      const response = await fetch('/api/users/me');
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      }
    } catch (error) {
      // User not logged in
    }
  };

  const fetchMessages = async () => {
    try {
      const response = await fetch('/api/chat/messages');
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;
    
    // Check if user can post
    if (!user?.subscription_status?.canPost) {
      alert('Muda wa majaribio umeisha. Lipa TSH 2,000 kwa mwezi au TSH 24,000 kwa mwaka ili kuendelea kutuma ujumbe.');
      return;
    }

    try {
      const response = await fetch('/api/chat/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: newMessage,
          is_public: true,
        }),
      });

      if (response.ok) {
        setNewMessage('');
        fetchMessages(); // Refresh messages
      } else {
        const error = await response.json();
        if (error.requiresPayment) {
          alert(error.error);
        }
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('sw-TZ', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-md border border-green-200 h-[600px] flex flex-col">
          {/* Header */}
          <div className="p-6 border-b border-green-200 bg-gradient-to-r from-green-50 to-green-100 rounded-t-xl">
            <h2 className="text-xl font-bold text-green-800 mb-1">Mazungumzo ya Wakulima</h2>
            <p className="text-sm text-gray-600">Jisikilize na wakulima wenzako, uliza maswali na shiriki uzoefu</p>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length > 0 ? (
              messages.map((message) => (
                <div key={message.id} className="flex space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-medium">
                      {message.sender_id.toString().slice(-1)}
                    </span>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-sm font-medium text-gray-900">
                        Mkulima {message.sender_id}
                      </span>
                      <span className="text-xs text-gray-500">
                        {formatTime(message.created_at)}
                      </span>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-3 max-w-md">
                      <p className="text-sm text-gray-800">{message.message}</p>
                      
                      {message.image_url && (
                        <div className="mt-2">
                          <img
                            src={message.image_url}
                            alt="Shared image"
                            className="rounded-lg max-w-full h-auto"
                          />
                        </div>
                      )}
                      
                      {message.video_url && (
                        <div className="mt-2">
                          <video
                            src={message.video_url}
                            controls
                            className="rounded-lg max-w-full h-auto"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <Phone className="w-16 h-16 mx-auto" />
                </div>
                <h3 className="text-lg font-semibold text-gray-700 mb-2">Hakuna mazungumzo</h3>
                <p className="text-gray-500">Kuwa wa kwanza kutuma ujumbe</p>
              </div>
            )}
          </div>

          {/* Message Input */}
          <div className="border-t border-green-200 p-4">
            {!user?.subscription_status?.canPost && user && (
              <div className="mb-3 bg-orange-50 border border-orange-200 rounded-lg p-3">
                <p className="text-orange-700 text-sm">
                  <strong>Muda wa majaribio umeisha:</strong> Chagua TSH 2,000/mwezi au TSH 24,000/mwaka ili uweze kutuma ujumbe.
                </p>
              </div>
            )}
            <div className="flex space-x-3">
              <div className="flex-1">
                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder={user?.subscription_status?.canPost ? "Andika ujumbe wako..." : "Lipa ili uweze kutuma ujumbe..."}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none"
                  rows={2}
                  disabled={!user?.subscription_status?.canPost}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                />
              </div>
              
              <div className="flex flex-col space-y-2">
                <button
                  type="button"
                  className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                  title="Ongeza picha"
                >
                  <Image className="w-5 h-5" />
                </button>
                
                <button
                  type="button"
                  className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                  title="Ongeza video"
                >
                  <Video className="w-5 h-5" />
                </button>
                
                <button
                  onClick={sendMessage}
                  disabled={!newMessage.trim() || !user?.subscription_status?.canPost}
                  className="p-2 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  title={user?.subscription_status?.canPost ? "Tuma ujumbe" : "Lipa ili uweze kutuma ujumbe"}
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
