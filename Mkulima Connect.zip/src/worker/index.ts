import { Hono } from "hono";
import { cors } from "hono/cors";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

app.use("*", cors());

// Helper function to check if user is admin
const isAdmin = (user: any, profile?: any) => {
  return user?.email?.includes('admin') || 
         user?.google_user_data?.email?.includes('admin') ||
         user?.isAdmin === true ||
         profile?.is_admin === 1;
};

// Auth endpoints
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "User not found" }, 401);
  }
  
  // Check if user profile exists
  const profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(user.id).first();

  if (!profile) {
    // Create profile for new user
    await c.env.DB.prepare(
      "INSERT INTO user_profiles (user_id, name, profile_image_url, trial_starts_at) VALUES (?, ?, ?, ?)"
    ).bind(
      user.id, 
      user.google_user_data.name || "", 
      user.google_user_data.picture || null,
      new Date().toISOString()
    ).run();
  }

  return c.json({
    ...user,
    profile,
    isAdmin: isAdmin(user, profile)
  });
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Media upload endpoint
app.post("/api/upload", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "User not found" }, 401);
  }

  try {
    const formData = await c.req.formData();
    const file = formData.get('media') as File;
    
    if (!file) {
      return c.json({ error: "No file provided" }, 400);
    }

    // For now, return a placeholder URL - in production you'd upload to R2 or similar
    const fileName = `${Date.now()}-${file.name}`;
    const fileUrl = `https://placeholder-media.com/${fileName}`;
    
    return c.json({ url: fileUrl }, 200);
  } catch (error) {
    console.error('Upload error:', error);
    return c.json({ error: "Upload failed" }, 500);
  }
});

// Posts endpoints
app.get("/api/posts", async (c) => {
  const category = c.req.query("category");
  
  let query = `
    SELECT p.*, up.name as author_name 
    FROM posts p 
    LEFT JOIN user_profiles up ON p.user_id = up.user_id 
    WHERE p.is_active = 1
  `;
  
  const params = [];
  if (category) {
    query += " AND p.category = ?";
    params.push(category);
  }
  
  query += " ORDER BY p.created_at DESC";
  
  const stmt = params.length > 0 
    ? c.env.DB.prepare(`
      SELECT p.*, up.name as author_name, up.profile_image_url as author_profile_image 
      FROM posts p 
      LEFT JOIN user_profiles up ON p.user_id = up.user_id 
      WHERE p.is_active = 1 ${category ? 'AND p.category = ?' : ''}
      ORDER BY p.created_at DESC
    `).bind(...params)
    : c.env.DB.prepare(`
      SELECT p.*, up.name as author_name, up.profile_image_url as author_profile_image 
      FROM posts p 
      LEFT JOIN user_profiles up ON p.user_id = up.user_id 
      WHERE p.is_active = 1 
      ORDER BY p.created_at DESC
    `);
    
  const { results } = await stmt.all();
  
  // Map old image_url/video_url to new media_url format for backward compatibility
  const mappedResults = results.map((post: any) => ({
    ...post,
    image_url: post.media_type === 'image' ? post.media_url : post.image_url,
    video_url: post.media_type === 'video' ? post.media_url : post.video_url
  }));
  
  return c.json(mappedResults);
});

app.post("/api/posts", authMiddleware, async (c) => {
  const user = c.get("user");
  const body = await c.req.json();
  
  if (!user) {
    return c.json({ error: "User not found" }, 401);
  }

  // Get user profile to check admin status
  const profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(user.id).first();

  // Check if admin or valid subscription for non-admin users
  if (!isAdmin(user, profile)) {
    // Check subscription status
    const userProfile = await c.env.DB.prepare(
      "SELECT * FROM user_profiles WHERE user_id = ?"
    ).bind(user.id).first();
    
    if (!userProfile) {
      return c.json({ error: "Profile not found" }, 404);
    }

    // For "bei" category, only admin can post
    if (body.category === 'bei') {
      return c.json({ error: "Only admin can post prices" }, 403);
    }

    // Check if trial has expired (14 days)
    const trialStartDate = new Date(userProfile.trial_starts_at as string);
    const now = new Date();
    const daysSinceTrialStart = (now.getTime() - trialStartDate.getTime()) / (1000 * 60 * 60 * 24);
    
    const hasActiveSubscription = userProfile.subscription_status === 'active' && 
      (!userProfile.subscription_expires_at || new Date(userProfile.subscription_expires_at as string) > now);
    
    const isInTrial = userProfile.subscription_status === 'trial' && daysSinceTrialStart <= 14;
    
    if (!hasActiveSubscription && !isInTrial) {
      return c.json({ 
        error: "Subscription required", 
        message: "Jaribio lako la siku 14 limeisha. Lipia TZS 2,000 kuendelea kutumia huduma hii.",
        subscription_required: true 
      }, 403);
    }
  }

  // Create post
  const result = await c.env.DB.prepare(
    "INSERT INTO posts (user_id, category, title, description, price, location, media_url, media_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
  ).bind(
    user.id,
    body.category,
    body.title,
    body.description,
    body.price || null,
    body.location || null,
    body.media_url || null,
    body.media_type || null
  ).run();

  return c.json({ id: result.meta.last_row_id, success: true });
});

// Profile image update endpoint
app.put("/api/profile/image", authMiddleware, async (c) => {
  const user = c.get("user");
  const body = await c.req.json();
  
  if (!user) {
    return c.json({ error: "User not found" }, 401);
  }

  await c.env.DB.prepare(
    "UPDATE user_profiles SET profile_image_url = ?, updated_at = ? WHERE user_id = ?"
  ).bind(body.profile_image_url, new Date().toISOString(), user.id).run();

  return c.json({ success: true });
});

// Comments endpoints
app.get("/api/posts/:postId/comments", async (c) => {
  const postId = c.req.param("postId");
  
  const { results } = await c.env.DB.prepare(`
    SELECT c.*, up.name as author_name 
    FROM comments c 
    LEFT JOIN user_profiles up ON c.user_id = up.user_id 
    WHERE c.post_id = ?
    ORDER BY c.created_at ASC
  `).bind(postId).all();
  
  return c.json(results);
});

app.post("/api/posts/:postId/comments", authMiddleware, async (c) => {
  const user = c.get("user");
  const postId = c.req.param("postId");
  const body = await c.req.json();
  
  if (!user) {
    return c.json({ error: "User not found" }, 401);
  }

  // Get user profile to check admin status
  const profileForComment = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(user.id).first();

  // Check if admin or valid subscription
  if (!isAdmin(user, profileForComment)) {
    if (!profileForComment) {
      return c.json({ error: "Profile not found" }, 404);
    }
    
    // Check subscription status for comments
    const trialStartDate = new Date(profileForComment.trial_starts_at as string);
    const now = new Date();
    const daysSinceTrialStart = (now.getTime() - trialStartDate.getTime()) / (1000 * 60 * 60 * 24);
    
    const hasActiveSubscription = profileForComment.subscription_status === 'active' && 
      (!profileForComment.subscription_expires_at || new Date(profileForComment.subscription_expires_at as string) > now);
    
    const isInTrial = profileForComment.subscription_status === 'trial' && daysSinceTrialStart <= 14;
    
    if (!hasActiveSubscription && !isInTrial) {
      return c.json({ 
        error: "Subscription required", 
        message: "Jaribio lako la siku 14 limeisha. Lipia TZS 2,000 kuendelea kutumia huduma hii.",
        subscription_required: true 
      }, 403);
    }
  }

  const result = await c.env.DB.prepare(
    "INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)"
  ).bind(postId, user.id, body.content).run();

  return c.json({ id: result.meta.last_row_id, success: true });
});

// Subscription management endpoints
app.get("/api/admin/subscriptions", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "User not found" }, 401);
  }
  
  // Get user profile to check admin status
  const profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (!isAdmin(user, profile)) {
    return c.json({ error: "Admin access required" }, 403);
  }

  const { results } = await c.env.DB.prepare(`
    SELECT 
      user_id,
      name,
      subscription_status,
      trial_starts_at,
      subscription_expires_at,
      CASE 
        WHEN subscription_status = 'trial' AND datetime(trial_starts_at, '+14 days') < datetime('now') THEN 1
        ELSE 0
      END as is_expired,
      CASE 
        WHEN subscription_status = 'trial' THEN 14 - (julianday('now') - julianday(trial_starts_at))
        ELSE 0
      END as trial_days_remaining
    FROM user_profiles
    ORDER BY created_at DESC
  `).all();

  return c.json(results);
});

app.put("/api/admin/subscription", authMiddleware, async (c) => {
  const user = c.get("user");
  const body = await c.req.json();
  
  if (!user) {
    return c.json({ error: "User not found" }, 401);
  }
  
  // Get user profile to check admin status
  const profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (!isAdmin(user, profile)) {
    return c.json({ error: "Admin access required" }, 403);
  }

  await c.env.DB.prepare(
    "UPDATE user_profiles SET subscription_status = ?, subscription_expires_at = ?, updated_at = ? WHERE user_id = ?"
  ).bind(
    body.subscription_status,
    body.subscription_expires_at,
    new Date().toISOString(),
    body.user_id
  ).run();

  return c.json({ success: true });
});

// Admin endpoints
app.get("/api/admin/stats", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "User not found" }, 401);
  }
  
  // Get user profile to check admin status
  const profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (!isAdmin(user, profile)) {
    return c.json({ error: "Admin access required" }, 403);
  }

  const { results: stats } = await c.env.DB.prepare(`
    SELECT 
      (SELECT COUNT(*) FROM user_profiles) as total_users,
      (SELECT COUNT(*) FROM posts WHERE is_active = 1) as total_posts,
      (SELECT COUNT(*) FROM comments) as total_comments,
      (SELECT COUNT(*) FROM user_profiles WHERE subscription_status = 'trial') as trial_users,
      (SELECT COUNT(*) FROM user_profiles WHERE subscription_status = 'active') as active_subscribers
  `).all();

  return c.json(stats[0]);
});

app.delete("/api/admin/posts", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "User not found" }, 401);
  }
  
  // Get user profile to check admin status
  const profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (!isAdmin(user, profile)) {
    return c.json({ error: "Admin access required" }, 403);
  }

  await c.env.DB.prepare("UPDATE posts SET is_active = 0").run();
  
  return c.json({ success: true, message: "All posts deactivated" });
});

export default app;
