import { useState } from 'react';
import { X, Camera, User } from 'lucide-react';
import { useAuth } from '@getmocha/users-service/react';

interface ProfileModalProps {
  onClose: () => void;
}

export default function ProfileModal({ onClose }: ProfileModalProps) {
  const { user } = useAuth();
  const [profileImage, setProfileImage] = useState((user as any)?.profile?.profile_image_url || '');
  const [loading, setLoading] = useState(false);

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('Picha kubwa sana. Chagua picha ndogo ya MB 5');
      return;
    }

    // Check file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!validTypes.includes(file.type)) {
      alert('Aina ya faili haifai. Chagua picha tu (JPG au PNG)');
      return;
    }

    setLoading(true);
    
    try {
      // Upload image
      const formData = new FormData();
      formData.append('media', file);
      
      const uploadResponse = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (uploadResponse.ok) {
        const uploadResult = await uploadResponse.json();
        setProfileImage(uploadResult.url);
        
        // Update profile
        const updateResponse = await fetch('/api/profile/image', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            profile_image_url: uploadResult.url
          }),
        });

        if (updateResponse.ok) {
          alert('Picha ya profile imebadilishwa kwa mafanikio!');
          window.location.reload(); // Refresh to show new image
        } else {
          alert('Imeshindwa kubadilisha picha');
        }
      } else {
        alert('Imeshindwa kupakia picha');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      alert('Hitilafu imetokea wakati wa kupakia picha');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold">Profile Yangu</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Profile Image Section */}
          <div className="text-center">
            <div className="relative inline-block">
              <div className="w-24 h-24 bg-green-600 rounded-full flex items-center justify-center overflow-hidden mx-auto mb-4">
                {profileImage ? (
                  <img 
                    src={profileImage} 
                    alt="Profile"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-10 h-10 text-white" />
                )}
              </div>
              
              <label className="absolute -bottom-1 -right-1 bg-green-600 hover:bg-green-700 text-white p-2 rounded-full cursor-pointer transition-colors">
                <Camera className="w-4 h-4" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  disabled={loading}
                />
              </label>
            </div>
            
            <p className="text-sm text-gray-500 mb-2">
              Bonyeza kamera kubadilisha picha yako
            </p>
            {loading && (
              <p className="text-sm text-green-600">Inapakia picha...</p>
            )}
          </div>

          {/* User Info */}
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Jina
              </label>
              <div className="px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                {user?.google_user_data?.name || 'Haijulikani'}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <div className="px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                {user?.google_user_data?.email || 'Haijulikani'}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Hali ya Uanachama
              </label>
              <div className="px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                <span className={`px-2 py-1 text-xs rounded-full ${
                  (user as any)?.profile?.subscription_status === 'active' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {(user as any)?.profile?.subscription_status === 'active' ? 'Mwanachama' : 'Jaribio'}
                </span>
              </div>
            </div>
          </div>

          {/* Close Button */}
          <button
            onClick={onClose}
            className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors"
          >
            Funga
          </button>
        </div>
      </div>
    </div>
  );
}
