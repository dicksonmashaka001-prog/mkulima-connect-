import { useState, useEffect } from 'react';
import { 
  Users, 
  BarChart3, 
  Trash2, 
  Settings, 
  Shield,
  Activity,
  TrendingUp,
  MessageSquare,
  FileText,
  DollarSign,
  CreditCard
} from 'lucide-react';
import SubscriptionManager from '@/react-app/components/SubscriptionManager';

interface AdminSettingsProps {
  onClose: () => void;
}

interface AppStats {
  total_users: number;
  total_posts: number;
  total_comments: number;
  trial_users: number;
  active_subscribers: number;
}

export default function AdminSettings({ onClose }: AdminSettingsProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState<AppStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [showSubscriptionManager, setShowSubscriptionManager] = useState(false);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/stats');
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAllPosts = async () => {
    if (confirm('Je, una uhakika unataka kufuta posts zote? Hii haiwezi kurudiowa!')) {
      try {
        const response = await fetch('/api/admin/posts', {
          method: 'DELETE',
        });
        if (response.ok) {
          alert('Posts zote zimefutwa kwa mafanikio');
          fetchStats();
        }
      } catch (error) {
        console.error('Error deleting posts:', error);
        alert('Hitilafu imetokea wakati wa kufuta posts');
      }
    }
  };

  const tabs = [
    { id: 'overview', name: 'Muhtasari', icon: BarChart3 },
    { id: 'users', name: 'Watumiaji', icon: Users },
    { id: 'payments', name: 'Malipo', icon: CreditCard },
    { id: 'content', name: 'Maudhui', icon: FileText },
    { id: 'settings', name: 'Mipangilio', icon: Settings },
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-green-600 to-green-700">
          <div className="flex items-center space-x-3">
            <Shield className="w-6 h-6 text-white" />
            <h2 className="text-xl font-semibold text-white">Mipangilio ya Admin</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors text-white"
          >
            ×
          </button>
        </div>

        <div className="flex">
          {/* Sidebar */}
          <div className="w-64 bg-gray-50 border-r">
            <nav className="p-4 space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-green-600 text-white'
                        : 'text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{tab.name}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Content */}
          <div className="flex-1 p-6 overflow-y-auto max-h-[calc(90vh-100px)]">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Muhtasari wa App</h3>
                
                {loading ? (
                  <div className="animate-pulse space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="h-20 bg-gray-200 rounded-lg"></div>
                    ))}
                  </div>
                ) : stats ? (
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Users className="w-8 h-8 text-blue-600" />
                        <div>
                          <p className="text-2xl font-bold text-blue-900">{stats.total_users}</p>
                          <p className="text-sm text-blue-600">Watumiaji Wote</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FileText className="w-8 h-8 text-green-600" />
                        <div>
                          <p className="text-2xl font-bold text-green-900">{stats.total_posts}</p>
                          <p className="text-sm text-green-600">Posts Zote</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <MessageSquare className="w-8 h-8 text-purple-600" />
                        <div>
                          <p className="text-2xl font-bold text-purple-900">{stats.total_comments}</p>
                          <p className="text-sm text-purple-600">Maoni Yote</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-yellow-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Activity className="w-8 h-8 text-yellow-600" />
                        <div>
                          <p className="text-2xl font-bold text-yellow-900">{stats.trial_users}</p>
                          <p className="text-sm text-yellow-600">Watumiaji wa Jaribio</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <DollarSign className="w-8 h-8 text-red-600" />
                        <div>
                          <p className="text-2xl font-bold text-red-900">{stats.active_subscribers}</p>
                          <p className="text-sm text-red-600">Waliojiunga</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-indigo-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <TrendingUp className="w-8 h-8 text-indigo-600" />
                        <div>
                          <p className="text-2xl font-bold text-indigo-900">
                            {Math.round((stats.active_subscribers / stats.total_users) * 100)}%
                          </p>
                          <p className="text-sm text-indigo-600">Kiwango cha Kujiunga</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Imeshindwa kupata takwimu</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'users' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Usimamizi wa Watumiaji</h3>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-medium text-green-900 mb-2">Mamlaka ya Admin</h4>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Kutumia app bila kikomo</li>
                    <li>• Kupost bei za mazao</li>
                    <li>• Kusimamia watumiaji wote</li>
                    <li>• Kuona takwimu za app</li>
                    <li>• Kufuta maudhui yoyote</li>
                  </ul>
                </div>
                
                <div className="space-y-3">
                  <button className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2">
                    <Users className="w-5 h-5" />
                    <span>Orodha ya Watumiaji</span>
                  </button>
                  
                  <button className="w-full bg-yellow-600 text-white py-3 rounded-lg hover:bg-yellow-700 transition-colors flex items-center justify-center space-x-2">
                    <Shield className="w-5 h-5" />
                    <span>Simamia Michakato</span>
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'payments' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Usimamizi wa Malipo</h3>
                
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">💰 Mfumo wa Malipo</h4>
                  <p className="text-sm text-blue-700 mb-3">
                    Watumiaji wanapata siku 14 za jaribio, halafu lazima walipe TZS 2,000 kila mwezi.
                  </p>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Jaribio: Siku 14 za bure</li>
                    <li>• Uanachama: TZS 2,000/mwezi</li>
                    <li>• Admin: Bila malipo</li>
                  </ul>
                </div>
                
                <div className="space-y-3">
                  <button
                    onClick={() => setShowSubscriptionManager(true)}
                    className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
                  >
                    <CreditCard className="w-5 h-5" />
                    <span>Simamia Malipo ya Watumiaji</span>
                  </button>
                  
                  <button className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center space-x-2">
                    <DollarSign className="w-5 h-5" />
                    <span>Ripoti za Mapato</span>
                  </button>
                  
                  <button className="w-full bg-orange-600 text-white py-3 rounded-lg hover:bg-orange-700 transition-colors flex items-center justify-center space-x-2">
                    <TrendingUp className="w-5 h-5" />
                    <span>Takwimu za Uongozi</span>
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'content' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Usimamizi wa Maudhui</h3>
                
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h4 className="font-medium text-red-900 mb-2">⚠️ Hatua za Hatari</h4>
                  <p className="text-sm text-red-700 mb-4">
                    Vitendo hivi haviwezi kurudiowa. Hakikisha kabla ya kubonyeza.
                  </p>
                  
                  <button
                    onClick={handleDeleteAllPosts}
                    className="w-full bg-red-600 text-white py-3 rounded-lg hover:bg-red-700 transition-colors flex items-center justify-center space-x-2"
                  >
                    <Trash2 className="w-5 h-5" />
                    <span>Futa Posts Zote</span>
                  </button>
                </div>
                
                <div className="space-y-3">
                  <button className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center space-x-2">
                    <MessageSquare className="w-5 h-5" />
                    <span>Simamia Maoni</span>
                  </button>
                  
                  <button className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center space-x-2">
                    <FileText className="w-5 h-5" />
                    <span>Ripoti za Maudhui</span>
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Mipangilio ya Mfumo</h3>
                
                <div className="space-y-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-2">Mipangilio ya Bei</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Badilisha bei za kujiunga na mikopo
                    </p>
                    <button className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                      Hariri Bei
                    </button>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-2">Mipangilio ya Notification</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Dhibiti ujumbe na arifa kwa watumiaji
                    </p>
                    <button className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                      Mipangilio ya Arifa
                    </button>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-2">Database Backup</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Hifadhi na rejesha data ya app
                    </p>
                    <div className="space-x-2">
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        Backup Sasa
                      </button>
                      <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                        Rejesha Data
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Subscription Manager Modal */}
      {showSubscriptionManager && (
        <SubscriptionManager onClose={() => setShowSubscriptionManager(false)} />
      )}
    </div>
  );
}
