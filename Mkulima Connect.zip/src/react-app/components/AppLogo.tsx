export default function AppLogo() {
  return (
    <div className="fixed bottom-4 right-4 z-30">
      <div className="bg-white rounded-lg p-2 shadow-lg border border-gray-200">
        <img 
          src="https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/file_000000003c8861f78efcf942d3ef3a50-(1).png" 
          alt="Mkulima Connect Logo" 
          className="w-12 h-12 object-contain"
        />
      </div>
    </div>
  );
}
