import { MessageCircle, MapPin, User, Heart, Share } from 'lucide-react';
import { Post } from '@/shared/types';
import { useState } from 'react';

interface PostCardProps {
  post: Post;
}

export default function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(false);
  const [showComments, setShowComments] = useState(false);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('sw-KE', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatPrice = (price: number | null) => {
    if (!price) return null;
    return new Intl.NumberFormat('sw-KE', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0
    }).format(price);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow mb-4">
      {/* Post Header */}
      <div className="p-4 flex items-center space-x-3">
        <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center overflow-hidden">
          {post.author_profile_image ? (
            <img 
              src={post.author_profile_image} 
              alt={post.author_name || 'Mtumiaji'}
              className="w-full h-full object-cover"
            />
          ) : (
            <User className="w-5 h-5 text-white" />
          )}
        </div>
        <div className="flex-1">
          <h4 className="font-semibold text-gray-900">
            {post.author_name || 'Mtumiaji'}
          </h4>
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <span>{formatDate(post.created_at)}</span>
            {post.location && (
              <>
                <span>•</span>
                <div className="flex items-center space-x-1">
                  <MapPin className="w-3 h-3" />
                  <span>{post.location}</span>
                </div>
              </>
            )}
          </div>
        </div>
        {post.price && (
          <div className="text-right">
            <span className="text-lg font-bold text-green-600">
              {formatPrice(post.price)}
            </span>
          </div>
        )}
      </div>

      {/* Post Content */}
      <div className="px-4 pb-3">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          {post.title}
        </h3>
        {post.description && (
          <p className="text-gray-700 leading-relaxed">
            {post.description}
          </p>
        )}
      </div>

      {/* Media Content */}
      {(post.image_url || post.video_url) && (
        <div className="relative bg-gray-100">
          {post.video_url ? (
            <video 
              src={post.video_url} 
              className="w-full max-h-96 object-cover"
              controls
              preload="metadata"
            />
          ) : post.image_url ? (
            <img
              src={post.image_url}
              alt={post.title}
              className="w-full max-h-96 object-cover"
              loading="lazy"
            />
          ) : null}
        </div>
      )}

      {/* Post Actions */}
      <div className="p-4 border-t border-gray-100">
        <div className="flex items-center justify-between">
          {/* Action Buttons */}
          <div className="flex items-center space-x-6">
            <button
              onClick={() => setLiked(!liked)}
              className={`flex items-center space-x-2 transition-colors ${
                liked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
              }`}
            >
              <Heart className={`w-5 h-5 ${liked ? 'fill-current' : ''}`} />
              <span className="text-sm font-medium">Penda</span>
            </button>

            <button
              onClick={() => setShowComments(!showComments)}
              className="flex items-center space-x-2 text-gray-500 hover:text-green-600 transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">Jibu</span>
            </button>

            <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-600 transition-colors">
              <Share className="w-5 h-5" />
              <span className="text-sm font-medium">Shiriki</span>
            </button>
          </div>
        </div>

        {/* Comments Section */}
        {showComments && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <div className="text-center py-4">
              <p className="text-gray-500 text-sm">Hakuna maoni bado</p>
            </div>

            {/* Comment Input */}
            <div className="mt-4 flex space-x-3">
              <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center overflow-hidden">
                <User className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Andika jibu lako..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
