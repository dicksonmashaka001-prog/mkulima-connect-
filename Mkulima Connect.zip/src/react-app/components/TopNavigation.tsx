import { categories } from '@/shared/types';
import { Bell, User, Settings } from 'lucide-react';
import { useAuth } from '@getmocha/users-service/react';
import { useState } from 'react';
import AdminSettings from '@/react-app/components/AdminSettings';
import ProfileModal from '@/react-app/components/ProfileModal';

interface TopNavigationProps {
  activeCategory: string;
  onCategoryChange: (category: string) => void;
}

export default function TopNavigation({ activeCategory, onCategoryChange }: TopNavigationProps) {
  const { user } = useAuth();
  const [showProfile, setShowProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);

  // Check if user is admin (any admin user)
  const isAdmin = user?.email?.includes('admin') || 
                  user?.google_user_data?.email?.includes('admin') ||
                  (user as any)?.profile?.is_admin === 1 ||
                  (user as any)?.isAdmin === true;

  return (
    <>
      {/* App Header */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center border border-gray-200 p-1">
                <img 
                  src="https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/file_000000003c8861f78efcf942d3ef3a50-(1).png" 
                  alt="Mkulima Connect Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <h1 className="text-xl font-bold text-gray-900">Mkulima Connect</h1>
            </div>

            {/* Right Section */}
            <div className="flex items-center space-x-4">
              {/* Admin Settings */}
              {isAdmin && (
                <button
                  onClick={() => setShowSettings(true)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-700"
                >
                  <Settings className="w-5 h-5" />
                </button>
              )}

              {/* Notifications */}
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-700">
                <Bell className="w-5 h-5" />
              </button>

              {/* Profile Menu */}
              {user && (
                <div className="relative">
                  <button
                    onClick={() => setShowProfile(!showProfile)}
                    className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center overflow-hidden">
                      {(user as any)?.profile?.profile_image_url ? (
                        <img 
                          src={(user as any).profile.profile_image_url} 
                          alt={user?.google_user_data?.name || 'Mtumiaji'}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="w-4 h-4 text-white" />
                      )}
                    </div>
                    <span className="text-sm font-medium hidden md:block text-gray-900">
                      {user?.google_user_data?.name || 'Mtumiaji'}
                    </span>
                  </button>

                  {showProfile && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border overflow-hidden">
                      <div className="px-4 py-3">
                        <p className="text-sm font-medium text-gray-900">
                          {user?.google_user_data?.name}
                        </p>
                        <p className="text-sm text-gray-500">
                          Mtumiaji wa Mkulima Connect
                        </p>
                        {isAdmin && (
                          <span className="inline-block mt-1 px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                            Admin
                          </span>
                        )}
                      </div>
                      <div className="border-t">
                        <button
                          onClick={() => {
                            setShowProfile(false);
                            setShowProfileModal(true);
                          }}
                          className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                        >
                          Profile Yangu
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Category Navigation */}
      <nav className="fixed top-16 left-0 right-0 bg-green-600 shadow-lg z-40">
        <div className="grid grid-cols-5 h-14">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => onCategoryChange(category.id)}
              className={`flex flex-col items-center justify-center space-y-1 transition-colors ${
                activeCategory === category.id
                  ? 'text-white bg-green-700'
                  : 'text-green-100 hover:text-white hover:bg-green-700'
              }`}
            >
              <img 
                src={category.icon} 
                alt={category.name}
                className="w-6 h-6 object-cover rounded"
              />
              <span className="text-xs font-medium leading-tight text-center px-1">
                {category.name.split(' ')[0]}
              </span>
            </button>
          ))}
        </div>
      </nav>

      {/* Admin Settings Modal */}
      {showSettings && isAdmin && (
        <AdminSettings onClose={() => setShowSettings(false)} />
      )}

      {/* Profile Modal */}
      {showProfileModal && (
        <ProfileModal onClose={() => setShowProfileModal(false)} />
      )}
    </>
  );
}
