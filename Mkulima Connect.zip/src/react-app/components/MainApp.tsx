import { useState } from 'react';
import CategoryScreen from '@/react-app/components/CategoryScreen';
import TopNavigation from '@/react-app/components/TopNavigation';
import AppLogo from '@/react-app/components/AppLogo';

export default function MainApp() {
  const [activeCategory, setActiveCategory] = useState('mazao');

  return (
    <div className="min-h-screen bg-gray-50">
      <TopNavigation 
        activeCategory={activeCategory} 
        onCategoryChange={setActiveCategory} 
      />
      
      <main className="pt-32 pb-24">
        <CategoryScreen category={activeCategory} />
      </main>

      <AppLogo />
    </div>
  );
}
