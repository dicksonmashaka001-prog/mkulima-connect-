import { useAuth } from '@getmocha/users-service/react';
import { LogIn, Smartphone } from 'lucide-react';

export default function LoginScreen() {
  const { redirectToLogin } = useAuth();

  const features = [
    {
      icon: <img src="https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/Screenshot_20250825_132916_Google.jpg" alt="Mazao" className="w-8 h-8 object-cover rounded" />,
      title: "Mazao",
      description: "Tangaza mazao yako kwa jamii nzima"
    },
    {
      icon: <img src="https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/Screenshot_20250825_133311_Google.jpg" alt="Pembejeo" className="w-8 h-8 object-cover rounded" />,
      title: "Pembejeo",
      description: "Pata pembejeo bora za kilimo"
    },
    {
      icon: <img src="https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/Screenshot_20250825_133344_Google.jpg" alt="Mafunzo" className="w-8 h-8 object-cover rounded" />,
      title: "Mafunzo",
      description: "Pata mafunzo ya kisasa ya kilimo"
    },
    {
      icon: <img src="https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/Screenshot_20250825_133418_Google.jpg" alt="Bei za Mazao" className="w-8 h-8 object-cover rounded" />,
      title: "Bei za Mazao",
      description: "Fuatilia bei za mazao Afrika Mashariki"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-600 via-green-500 to-emerald-400">
      {/* Hero Section */}
      <div className="flex flex-col items-center justify-center min-h-screen px-4 py-8">
        <div className="max-w-4xl mx-auto text-center">
          {/* Logo */}
          <div className="mb-8">
            <div className="w-24 h-24 mx-auto bg-white/90 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/20 shadow-2xl p-3">
              <img 
                src="https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/file_000000003c8861f78efcf942d3ef3a50-(1).png" 
                alt="Mkulima Connect Logo" 
                className="w-full h-full object-contain"
              />
            </div>
          </div>

          {/* Main Content */}
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">
            Mkulima Connect
          </h1>
          
          <p className="text-xl md:text-2xl text-green-100 font-medium mb-4">
            Mapinduzi ya Kilimo ya Kweli
          </p>
          
          <p className="text-lg text-green-200 mb-12 max-w-2xl mx-auto">
            Jiunge na jamii ya wakulima wa Afrika Mashariki. Tangaza mazao, pata pembejeo, 
            pata mafunzo na fuatilia bei za mazao.
          </p>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {features.map((feature, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="text-white mb-4 flex justify-center">
                  {feature.icon}
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">{feature.title}</h3>
                <p className="text-green-100 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>

          {/* Login Section */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 max-w-md mx-auto">
            <h2 className="text-2xl font-bold text-white mb-6">
              Jiunge Sasa
            </h2>
            
            <button
              onClick={redirectToLogin}
              className="w-full bg-white hover:bg-gray-100 text-green-600 font-semibold py-4 px-6 rounded-xl transition-colors duration-200 flex items-center justify-center space-x-3 mb-4"
            >
              <LogIn className="w-5 h-5" />
              <span>Ingia kwa Google</span>
            </button>

            <div className="flex items-center space-x-2 text-green-100 text-sm">
              <Smartphone className="w-4 h-4" />
              <span>Jaribio la bure la siku 14, kisha Tsh 2,000/mwezi</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
