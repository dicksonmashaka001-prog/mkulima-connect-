import { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { categories, Post } from '@/shared/types';
import PostCard from '@/react-app/components/PostCard';
import CreatePostModal from '@/react-app/components/CreatePostModal';
import { useAuth } from '@getmocha/users-service/react';

interface CategoryScreenProps {
  category: string;
}

export default function CategoryScreen({ category }: CategoryScreenProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const { user } = useAuth();

  const categoryInfo = categories.find(c => c.id === category);
  
  // Check if user is admin
  const isAdmin = user?.email?.includes('admin') || 
                  user?.google_user_data?.email?.includes('admin') ||
                  (user as any)?.profile?.is_admin === 1 ||
                  (user as any)?.isAdmin === true;

  // Check subscription status
  const checkSubscriptionStatus = () => {
    if (!user) return false;
    
    const profile = (user as any)?.profile;
    if (!profile) return false;
    
    // Admin always has access
    if (isAdmin) return true;
    
    // Check if subscription is active
    if (profile.subscription_status === 'active') {
      if (!profile.subscription_expires_at || new Date(profile.subscription_expires_at) > new Date()) {
        return true;
      }
    }
    
    // Check if still in trial period (14 days)
    if (profile.subscription_status === 'trial') {
      const trialStartDate = new Date(profile.trial_starts_at);
      const now = new Date();
      const daysSinceTrialStart = (now.getTime() - trialStartDate.getTime()) / (1000 * 60 * 60 * 24);
      return daysSinceTrialStart <= 14;
    }
    
    return false;
  };

  useEffect(() => {
    fetchPosts();
  }, [category]);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/posts?category=${category}`);
      const data = await response.json();
      setPosts(data);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  // Check if user can post (admin or valid subscription)
  const canPost = isAdmin || (user && category !== 'bei' && checkSubscriptionStatus());

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center space-x-3">
            <img 
              src={categoryInfo?.icon} 
              alt={categoryInfo?.name}
              className="w-8 h-8 object-cover rounded"
            />
            <span>{categoryInfo?.name}</span>
          </h1>
          <p className="text-gray-600 mt-1">
            {category === 'mazao' && 'Tangaza mazao yako hapa na uongee na walimaji wenzako'}
            {category === 'pembejeo' && 'Pata pembejeo bora za kilimo kutoka kwa wauza walio karibu nawe'}
            {category === 'mbolea' && 'Pata mbolea asilia bora kwa mazao yako'}
            {category === 'mafunzo' && 'Pata mafunzo ya kisasa ya kilimo kutoka kwa wataalamu'}
            {category === 'bei' && 'Fuatilia bei za mazao Afrika Mashariki'}
          </p>
        </div>
        
        {canPost && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-green-600 hover:bg-green-700 text-white p-3 rounded-full shadow-lg transition-colors"
          >
            <Plus className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Admin Notice for Bei Category */}
      {category === 'bei' && !isAdmin && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <p className="text-yellow-800 text-sm">
            📊 Bei za mazao zinatangazwa na msimamizi wa app tu. Hakikisha unafuatilia hapa kila siku kupata bei za kisasa.
          </p>
        </div>
      )}

      {/* Subscription Notice */}
      {!isAdmin && user && !checkSubscriptionStatus() && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
          <h4 className="font-medium text-red-900 mb-2">⚠️ Jaribio Limeisha</h4>
          <p className="text-red-800 text-sm mb-3">
            Jaribio lako la siku 14 limeisha. Lipia TZS 2,000 kuendelea kutumia huduma zote za app.
          </p>
          <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors text-sm">
            Lipia Sasa - TZS 2,000/Mwezi
          </button>
        </div>
      )}

      {/* Posts */}
      {loading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg p-6 shadow-sm border animate-pulse">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                <div>
                  <div className="h-4 bg-gray-200 rounded w-24 mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-16"></div>
                </div>
              </div>
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
              <div className="h-48 bg-gray-200 rounded"></div>
            </div>
          ))}
        </div>
      ) : posts.length === 0 ? (
        <div className="text-center py-12">
          <img 
            src={categoryInfo?.icon} 
            alt={categoryInfo?.name}
            className="w-16 h-16 object-cover rounded-lg mx-auto mb-4"
          />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Hakuna matangazo bado
          </h3>
          <p className="text-gray-500 mb-4">
            {canPost ? 'Kuwa wa kwanza kutangaza katika sehemu hii' : 'Hakuna matangazo ya kuonyesha kwa sasa'}
          </p>
          {canPost && (
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-colors"
            >
              Tangaza Sasa
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}

      {/* Create Post Modal */}
      {showCreateModal && canPost && (
        <CreatePostModal
          category={category}
          onClose={() => setShowCreateModal(false)}
          onSuccess={() => {
            setShowCreateModal(false);
            fetchPosts();
          }}
        />
      )}
    </div>
  );
}
