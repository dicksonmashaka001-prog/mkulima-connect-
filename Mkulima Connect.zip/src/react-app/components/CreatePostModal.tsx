import { useState, useRef } from 'react';
import { X, MapPin, DollarSign, Image, Video, Camera } from 'lucide-react';
import { categories } from '@/shared/types';

interface CreatePostModalProps {
  category: string;
  onClose: () => void;
  onSuccess: () => void;
}

export default function CreatePostModal({ category, onClose, onSuccess }: CreatePostModalProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    location: '',
  });
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const categoryInfo = categories.find(c => c.id === category);

  const handleMediaUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (max 50MB)
      if (file.size > 50 * 1024 * 1024) {
        alert('Faili kubwa sana. Chagua faili ndogo ya MB 50');
        return;
      }

      // Check file type
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'video/mp4', 'video/webm', 'video/ogg'];
      if (!validTypes.includes(file.type)) {
        alert('Aina ya faili haifai. Chagua picha au video tu');
        return;
      }

      setMediaFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setMediaPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeMedia = () => {
    setMediaFile(null);
    setMediaPreview('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      alert('Jaza jina la tangazo');
      return;
    }

    setLoading(true);
    
    try {
      let mediaUrl = '';
      
      // Upload media file if selected
      if (mediaFile) {
        const formDataUpload = new FormData();
        formDataUpload.append('media', mediaFile);
        
        const uploadResponse = await fetch('/api/upload', {
          method: 'POST',
          body: formDataUpload,
        });
        
        if (uploadResponse.ok) {
          const uploadResult = await uploadResponse.json();
          mediaUrl = uploadResult.url;
        }
      }

      // Create post
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          category,
          price: formData.price ? parseFloat(formData.price) : null,
          media_url: mediaUrl,
          media_type: mediaFile?.type.startsWith('video/') ? 'video' : 'image'
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create post');
      }

      onSuccess();
    } catch (error) {
      console.error('Error creating post:', error);
      alert('Hitilafu imetokea. Jaribu tena.');
    } finally {
      setLoading(false);
    }
  };

  const getPlaceholders = () => {
    switch (category) {
      case 'mazao':
        return {
          title: 'Mfano: Mahindi mazuri ya kitanda',
          description: 'Eleza mazao yako, hali, na maelezo mengine muhimu...',
          price: '50000'
        };
      case 'pembejeo':
        return {
          title: 'Mfano: Mbegu za mahindi ya kisasa',
          description: 'Eleza aina ya pembejeo, ubora, na maelezo mengine...',
          price: '15000'
        };
      case 'mbolea':
        return {
          title: 'Mfano: Mbolea asilia ya kuku',
          description: 'Eleza aina ya mbolea, ubora, na jinsi ya kutumia...',
          price: '25000'
        };
      case 'mafunzo':
        return {
          title: 'Mfano: Mafunzo ya kilimo cha kisasa',
          description: 'Eleza mafunzo utakayotoa, muda, na gharama...',
          price: '10000'
        };
      default:
        return {
          title: '',
          description: '',
          price: ''
        };
    }
  };

  const placeholders = getPlaceholders();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            <img 
              src={categoryInfo?.icon} 
              alt={categoryInfo?.name}
              className="w-6 h-6 object-cover rounded"
            />
            <h2 className="text-xl font-semibold">Tangaza {categoryInfo?.name}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Media Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Camera className="w-4 h-4 inline mr-1" />
              Picha au Video
            </label>
            
            {!mediaPreview ? (
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-green-500 hover:bg-green-50 transition-colors"
              >
                <div className="flex flex-col items-center space-y-2">
                  <div className="flex space-x-2 text-gray-400">
                    <Image className="w-8 h-8" />
                    <Video className="w-8 h-8" />
                  </div>
                  <p className="text-sm text-gray-500">
                    Bonyeza kupakia picha au video
                  </p>
                  <p className="text-xs text-gray-400">
                    JPG, PNG, GIF, MP4 (Hadi MB 50)
                  </p>
                </div>
              </div>
            ) : (
              <div className="relative">
                {mediaFile?.type.startsWith('video/') ? (
                  <video 
                    src={mediaPreview} 
                    className="w-full h-48 object-cover rounded-lg"
                    controls
                  />
                ) : (
                  <img 
                    src={mediaPreview} 
                    alt="Preview" 
                    className="w-full h-48 object-cover rounded-lg"
                  />
                )}
                <button
                  type="button"
                  onClick={removeMedia}
                  className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
            
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              onChange={handleMediaUpload}
              className="hidden"
            />
          </div>

          {/* Title */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Jina la Tangazo *
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder={placeholders.title}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Maelezo
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder={placeholders.description}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          {/* Price */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <DollarSign className="w-4 h-4 inline mr-1" />
              Bei (TZS)
            </label>
            <input
              type="number"
              value={formData.price}
              onChange={(e) => setFormData({ ...formData, price: e.target.value })}
              placeholder={placeholders.price}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <MapPin className="w-4 h-4 inline mr-1" />
              Mahali
            </label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              placeholder="Mfano: Dar es Salaam, Kinondoni"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          {/* Submit Button */}
          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Ghairi
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
            >
              {loading ? 'Inatangaza...' : 'Tangaza'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
