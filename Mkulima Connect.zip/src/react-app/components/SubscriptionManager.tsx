import { useState, useEffect } from 'react';
import { Clock, DollarSign, CheckCircle, AlertCircle, CreditCard } from 'lucide-react';

interface SubscriptionManagerProps {
  onClose: () => void;
}

interface SubscriptionData {
  user_id: string;
  name: string;
  subscription_status: string;
  trial_starts_at: string;
  subscription_expires_at: string | null;
  trial_days_remaining: number;
  is_expired: boolean;
}

export default function SubscriptionManager({ onClose }: SubscriptionManagerProps) {
  const [users, setUsers] = useState<SubscriptionData[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    fetchSubscriptionData();
  }, []);

  const fetchSubscriptionData = async () => {
    try {
      const response = await fetch('/api/admin/subscriptions');
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      }
    } catch (error) {
      console.error('Error fetching subscription data:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateSubscriptionStatus = async (userId: string, status: string) => {
    try {
      const response = await fetch('/api/admin/subscription', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: userId,
          subscription_status: status,
          subscription_expires_at: status === 'active' 
            ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days from now
            : null
        }),
      });

      if (response.ok) {
        alert('Hali ya uanachama imebadilishwa!');
        fetchSubscriptionData();
      }
    } catch (error) {
      console.error('Error updating subscription:', error);
      alert('Hitilafu imetokea');
    }
  };

  const getStatusBadge = (user: SubscriptionData) => {
    if (user.is_expired) {
      return (
        <span className="px-2 py-1 text-xs rounded-full bg-red-100 text-red-800 flex items-center space-x-1">
          <AlertCircle className="w-3 h-3" />
          <span>Muda Umeisha</span>
        </span>
      );
    }
    
    if (user.subscription_status === 'active') {
      return (
        <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 flex items-center space-x-1">
          <CheckCircle className="w-3 h-3" />
          <span>Amelipa</span>
        </span>
      );
    }
    
    return (
      <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800 flex items-center space-x-1">
        <Clock className="w-3 h-3" />
        <span>Jaribio ({Math.ceil(user.trial_days_remaining)} siku)</span>
      </span>
    );
  };

  const expiredUsers = users.filter(u => u.is_expired);
  const trialUsers = users.filter(u => !u.is_expired && u.subscription_status === 'trial');
  const activeUsers = users.filter(u => u.subscription_status === 'active');

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-5xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-blue-600 to-blue-700">
          <div className="flex items-center space-x-3">
            <CreditCard className="w-6 h-6 text-white" />
            <h2 className="text-xl font-semibold text-white">Msimamizi wa Malipo</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors text-white"
          >
            ×
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'overview', name: 'Muhtasari', count: users.length },
              { id: 'expired', name: 'Walioisha', count: expiredUsers.length },
              { id: 'trial', name: 'Jaribio', count: trialUsers.length },
              { id: 'active', name: 'Waliolipa', count: activeUsers.length },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 text-sm font-medium border-b-2 ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab.name} ({tab.count})
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {loading ? (
            <div className="animate-pulse space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          ) : (
            <>
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <DollarSign className="w-8 h-8 text-blue-600" />
                        <div>
                          <p className="text-2xl font-bold text-blue-900">{users.length}</p>
                          <p className="text-sm text-blue-600">Watumiaji Wote</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <AlertCircle className="w-8 h-8 text-red-600" />
                        <div>
                          <p className="text-2xl font-bold text-red-900">{expiredUsers.length}</p>
                          <p className="text-sm text-red-600">Walioisha Muda</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-yellow-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Clock className="w-8 h-8 text-yellow-600" />
                        <div>
                          <p className="text-2xl font-bold text-yellow-900">{trialUsers.length}</p>
                          <p className="text-sm text-yellow-600">Jaribio</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="w-8 h-8 text-green-600" />
                        <div>
                          <p className="text-2xl font-bold text-green-900">{activeUsers.length}</p>
                          <p className="text-sm text-green-600">Waliolipa</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <h4 className="font-medium text-orange-900 mb-2">📊 Takwimu za Mapato</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-orange-700">Mapato ya Mwezi:</p>
                        <p className="text-lg font-bold text-orange-900">
                          TZS {(activeUsers.length * 2000).toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-orange-700">Kiwango cha Kujiunga:</p>
                        <p className="text-lg font-bold text-orange-900">
                          {users.length > 0 ? Math.round((activeUsers.length / users.length) * 100) : 0}%
                        </p>
                      </div>
                      <div>
                        <p className="text-orange-700">Waliopenda (ARR):</p>
                        <p className="text-lg font-bold text-orange-900">
                          TZS {(activeUsers.length * 24000).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* User Lists */}
              {(activeTab === 'expired' || activeTab === 'trial' || activeTab === 'active') && (
                <div className="space-y-4">
                  {(activeTab === 'expired' ? expiredUsers : 
                    activeTab === 'trial' ? trialUsers : activeUsers).map((user) => (
                    <div key={user.user_id} className="bg-white border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{user.name || 'Jina halijulikani'}</h4>
                          <p className="text-sm text-gray-500">ID: {user.user_id.slice(0, 8)}...</p>
                          <div className="mt-2 flex items-center space-x-4 text-sm text-gray-600">
                            <span>Alianza: {new Date(user.trial_starts_at).toLocaleDateString('sw-KE')}</span>
                            {user.subscription_expires_at && (
                              <span>Itaisha: {new Date(user.subscription_expires_at).toLocaleDateString('sw-KE')}</span>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          {getStatusBadge(user)}
                          
                          <div className="flex space-x-2">
                            {user.subscription_status !== 'active' && (
                              <button
                                onClick={() => updateSubscriptionStatus(user.user_id, 'active')}
                                className="px-3 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                              >
                                Badilisha Kulipa
                              </button>
                            )}
                            
                            {user.subscription_status === 'active' && (
                              <button
                                onClick={() => updateSubscriptionStatus(user.user_id, 'trial')}
                                className="px-3 py-1 text-xs bg-yellow-600 text-white rounded hover:bg-yellow-700 transition-colors"
                              >
                                Rudisha Jaribio
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {(activeTab === 'expired' ? expiredUsers : 
                    activeTab === 'trial' ? trialUsers : activeUsers).length === 0 && (
                    <div className="text-center py-8">
                      <p className="text-gray-500">Hakuna watumiaji katika sehemu hii</p>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
