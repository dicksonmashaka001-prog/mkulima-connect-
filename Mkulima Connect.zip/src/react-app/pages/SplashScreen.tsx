import { useEffect, useState } from 'react';

export default function SplashScreen() {
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    setAnimate(true);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-600 via-green-500 to-emerald-400 flex items-center justify-center relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-32 h-32 bg-green-300/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-emerald-300/20 rounded-full blur-xl animate-pulse delay-700"></div>
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-green-400/10 rounded-full blur-lg animate-bounce delay-1000"></div>
      </div>

      <div className="text-center z-10 px-8">
        {/* App Logo/Icon */}
        <div className={`mb-8 transform transition-all duration-1000 ${animate ? 'scale-100 opacity-100' : 'scale-50 opacity-0'}`}>
          <div className="w-32 h-32 mx-auto bg-white/90 backdrop-blur-sm rounded-3xl flex items-center justify-center border border-white/20 shadow-2xl p-4">
            <img 
              src="https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/file_000000003c8861f78efcf942d3ef3a50-(1).png" 
              alt="Mkulima Connect Logo" 
              className="w-full h-full object-contain"
            />
          </div>
        </div>

        {/* App Name */}
        <div className={`transform transition-all duration-1000 delay-300 ${animate ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-tight">
            Mkulima Connect
          </h1>
          
          {/* Tagline */}
          <div className={`transform transition-all duration-1000 delay-500 ${animate ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
            <p className="text-xl md:text-2xl text-green-100 font-medium mb-2">
              Mapinduzi ya Kilimo
            </p>
            <p className="text-green-200 text-lg">
              Afrika Mashariki
            </p>
          </div>
        </div>

        {/* Loading indicator */}
        <div className={`mt-12 transform transition-all duration-1000 delay-700 ${animate ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
          <div className="flex justify-center space-x-2">
            <div className="w-3 h-3 bg-white/80 rounded-full animate-bounce"></div>
            <div className="w-3 h-3 bg-white/80 rounded-full animate-bounce delay-150"></div>
            <div className="w-3 h-3 bg-white/80 rounded-full animate-bounce delay-300"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
