import { useAuth } from '@getmocha/users-service/react';
import { Loader2 } from 'lucide-react';
import LoginScreen from '@/react-app/components/LoginScreen';
import MainApp from '@/react-app/components/MainApp';

export default function Home() {
  const { user, isPending } = useAuth();

  if (isPending) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-600 via-green-500 to-emerald-400 flex items-center justify-center">
        <div className="text-center text-white">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4" />
          <p className="text-xl">Kuanza mfumo...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginScreen />;
  }

  return <MainApp />;
}
