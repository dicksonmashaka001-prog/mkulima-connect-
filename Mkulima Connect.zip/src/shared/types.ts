import z from "zod";

export const PostSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  category: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  price: z.number().nullable(),
  location: z.string().nullable(),
  media_url: z.string().nullable(),
  media_type: z.string().nullable(),
  // Backward compatibility
  image_url: z.string().nullable().optional(),
  video_url: z.string().nullable().optional(),
  is_active: z.number(),
  author_name: z.string().nullable(),
  author_profile_image: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Post = z.infer<typeof PostSchema>;

export const UserProfileSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  name: z.string().nullable(),
  phone_number: z.string().nullable(),
  profile_image_url: z.string().nullable(),
  subscription_status: z.string(),
  subscription_expires_at: z.string().nullable(),
  trial_starts_at: z.string(),
  is_active: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type UserProfile = z.infer<typeof UserProfileSchema>;

// Extended MochaUser type with profile
export interface MochaUserWithProfile {
  id: string;
  email: string;
  google_user_data: {
    name: string;
    email: string;
    picture?: string;
  };
  profile?: UserProfile;
  isAdmin?: boolean;
}

export const categories = [
  { 
    id: "mazao", 
    name: "Mazao", 
    icon: "https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/Screenshot_20250825_132916_Google.jpg",
    emoji: "🌾"
  },
  { 
    id: "pembejeo", 
    name: "Pembejeo", 
    icon: "https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/Screenshot_20250825_133311_Google.jpg",
    emoji: "🛠️"
  },
  { 
    id: "mbolea", 
    name: "Mbolea", 
    icon: "https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/Screenshot_20250825_133217_Google.jpg",
    emoji: "🌱"
  },
  { 
    id: "mafunzo", 
    name: "Mafunzo", 
    icon: "https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/Screenshot_20250825_133344_Google.jpg",
    emoji: "📚"
  },
  { 
    id: "bei", 
    name: "Bei", 
    icon: "https://mocha-cdn.com/0198e099-8352-7875-8b83-0211fe373613/Screenshot_20250825_133418_Google.jpg",
    emoji: "💰"
  },
] as const;
