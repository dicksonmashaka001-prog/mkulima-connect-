
ALTER TABLE user_profiles DROP COLUMN profile_image_url;
