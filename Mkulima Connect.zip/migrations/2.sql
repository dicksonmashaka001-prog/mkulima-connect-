
ALTER TABLE user_profiles ADD COLUMN profile_image_url TEXT;
