
DROP TABLE notifications;
DROP TABLE comments;
DROP TABLE posts;
DROP TABLE user_profiles;
